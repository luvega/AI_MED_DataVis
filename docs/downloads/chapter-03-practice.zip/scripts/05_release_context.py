"""只核对构造释放表的对象与字段，供任务迁移。"""
from pathlib import Path
import csv
import json
root=Path(__file__).resolve().parents[1]
with (root/"data/raw/release_teaching.csv").open(encoding="utf-8-sig",newline="") as f:
    reader=csv.DictReader(f)
    fields=reader.fieldnames
    rows=list(reader)
result={"fields":fields,"records":len(rows),"units":len({r["unit_id"] for r in rows}),"preparations":len({r["preparation_id"] for r in rows}),"time_min":sorted({int(r["time_min"]) for r in rows}),"response":"release_percent"}
print(json.dumps(result,indent=2))
(root/"outputs").mkdir(exist_ok=True)
(root/"outputs/release_task_context.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
