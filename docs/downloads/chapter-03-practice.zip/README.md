# 第3章练习包

本包保留Lolamicin抗生素与葡萄糖响应胰岛素两项真实实验的完整读取、汇总和作图；释放构造表用于检验任务说明在更换实验后怎样修订。

在解压根目录运行，Python需要requirements.txt中的包。

```text
python scripts/01_read.py
python scripts/02_lolamicin.py
python scripts/03_insulin.py
python scripts/05_release_context.py
```

前三个入口对应3.1–3.3。还可运行 `python run_all.py` 完成相同主例和对比例。outputs保存本人生成图和汇总表。05读取12行构造释放表，只检查新问题的字段与对象，不拟合模型。

scripts/04_column_error.py是主动设置的列名排错练习，按正文和exercises.md单独运行；它不属于正常验收入口。先看真实列名和字典，再修改并重跑。

数据在data/raw，data_dictionary.md解释实验含义，task_template.md与records.md用于保存本人说明。独立任务先预测和作答，再检查实际输出。
