# 实验与数据字典

## A：抗生素处理后的可培养菌量

Muñoz等研究Lolamicin时，将E. coli BW25113培养物用药处理，在不同时间取样、连续稀释、涂布到无药平板，培养后计数并换算CFU/mL。CFU是菌落形成单位，反映在这些培养条件下能够形成菌落的单位数量；本表不是显微镜下逐个细胞的总计数。

处理为未处理对照、Lolamicin 4×MIC、环丙沙星4×MIC。MIC为最低抑菌浓度，4×MIC表示各药自身MIC的四倍，不表示两药的μg/mL相同。源表时间为1、2、4、8小时，图注说明生物学三重复。

| 字段 | 含义与单位 | 如何使用 |
|---|---|---|
| treatment | 源表处理名；三类 | 与time_h一起定义本次汇总组 |
| time_h | 取样时间，小时 | 四个时间点；没有0小时实测行 |
| repeat_column_index | 同一处理块中第1、2、3列 | 原表列序号，非另行取得的样本身份信息；不由序号自行建立跨处理配对检验 |
| value | CFU/mL，稀释换算后的菌落形成单位浓度 | 保留每次重复的值，先用原数值汇总 |
| unit | CFU/mL | 不能当OD或抑菌百分比 |
| replicate_definition | 作者图注的生物学三重复说明 | 36条记录不等于36个独立实验 |
| source_sheet | ED Fig. 3a | 作者工作簿页名 |
| source_cell | 原Excel单元格 | 精确定位value的来源 |

课堂表共36行：3处理×4时间×3重复。重复列中的较大值仍保留。方法给出的近似起始培养浓度不能补为表中不存在的0小时三条记录。

[论文：A Gram-negative-selective antibiotic that spares the gut microbiome](https://www.nature.com/articles/s41586-024-07502-0)，Nature 630, 429–436 (2024)，DOI:10.1038/s41586-024-07502-0。

[出版方Source Data工作簿](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41586-024-07502-0/MediaObjects/41586_2024_7502_MOESM9_ESM.xlsx)，ED Fig. 3a，响应单元格B2:J5。

## B：胰岛素竞争结合实验

Hoeg-Jensen等比较NNC2215和人胰岛素时，用未标记的待测分子与125I标记胰岛素竞争人胰岛素受体A（hIR-A）。检测与受体结合的放射性信号，以CPM（每分钟计数）记录。待测分子的置换作用增强时，标记配体的结合信号可降低；要结合实验设置解释读数方向。

本表选择3与20 mM D-glucose条件，每种分子各八个源表浓度、每个条件三个技术重复。原文还有其他葡萄糖条件和实验；这96行只对应Fig. 3a、3b中的选定部分。Fig. 3d的独立重复不是本表中的三孔。

| 字段 | 含义与单位 | 如何使用 |
|---|---|---|
| molecule | NNC2215 / Human insulin | 分别作图，后者是人胰岛素对照 |
| glucose_mM | D-glucose浓度，mM | 3或20，不是胰岛素的给药浓度 |
| concentration_label_original | 原始表头字符串 | 保留10的幂次写法以便回查 |
| concentration_M | 根据源表字符串换算的待测配体浓度，M | 对数横轴；两分子梯度不同，不按列号强行对齐 |
| technical_repeat_row | 同一葡萄糖条件块中的技术重复行序号，1、2、3 | 不是Excel绝对行号；原行号由source_cell定位，不代表独立动物或供者 |
| value | 检测信号，CPM | 不是受体活性百分比，也不是血糖浓度 |
| unit | CPM | counts per minute |
| source_sheet / source_cell | Figure 3a或Figure 3b及单元格 | 定位原始CPM值 |

浓度均保留源表值，包括首列`10^(-13)` M。原文方法另提到零未标记配体在拟合中的占位值；本次只按源表显示，不自行将首列改成0，不进行拟合或亲和力计算。

[论文：Glucose-sensitive insulin with attenuation of hypoglycaemia](https://www.nature.com/articles/s41586-024-08042-3)，Nature 634, 944–951 (2024)，DOI:10.1038/s41586-024-08042-3。

[出版方Source Data工作簿](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41586-024-08042-3/MediaObjects/41586_2024_8042_MOESM5_ESM.xlsx)，Figure 3a/3b，3 mM对应B9:I11，20 mM对应B21:I23。

## 文件与来源

两份CSV是作者公开源数据的课堂选取与长表整理，保留逐重复响应值和来源坐标，不是从图中估读。A的CFU/mL已经经过稀释换算；B是作者提供的CPM表。文件不等同于完整实验日志或仪器原生文件。引用本表时注明原论文及所用图号、条件；对外转载论文原图或整篇文章应另核出版许可。


# 释放表字典

release_teaching.csv为本次独立编写的教学构造数据，所有数值用于练习记录结构和操作，未进行真实释放实验。

| 字段 | 类型与含义 |
| --- | --- |
| preparation_id | 文本；构造示例的独立制备编号 |
| unit_id | 文本；同一制备内被测制剂单元编号 |
| formula | 文本；A/B处方标签 |
| time_min | 整数；测量时间，分钟 |
| release_percent | 数值；释放百分数 |
| condition_id | 文本；本例c01表示同一构造测量条件 |

一行对应某个单元在某个时间点的测量，共12行、4个单元、2个制备编号和3个时间。独立制备与单元层级均按示例说明保留，不以12行代替12个独立制备。
