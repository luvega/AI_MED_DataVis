# 数据字典

base24.csv与expanded200.csv均为教学构造，分别24/200行，彼此独立。

| 字段 | 含义与单位 | 类型 |
| --- | --- | --- |
| sample_id | 基础S01—S24，扩展E001—E200 | 字符编号 |
| group | control/treatment教学标签 | 分类 |
| dose | 教学剂量单位 | 数值 |
| ALT、AST | 教学检验值，U/L | 数值 |
| age | 教学年龄，岁 | 数值 |
| sex | F/M教学标签 | 分类 |
| response | 0阴性，1阳性教学结局 | 二分类 |

基础表有11个正类；扩展表有62个正类。分类指标使用当前拟合数据。generated_rules.py保存原有扩展数据构造规则，运行演示只读取CSV。
