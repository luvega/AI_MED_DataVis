"""逐步生成散点、回归诊断和阈值表，不修改输入。"""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy import stats
from sklearn.metrics import confusion_matrix,roc_auc_score,roc_curve
ROOT=Path(__file__).resolve().parents[1];RAW=ROOT/'data/raw';OUT=ROOT/'outputs';OUT.mkdir(exist_ok=True)
df=pd.read_csv(RAW/'base24.csv',encoding='utf-8-sig')
expanded=pd.read_csv(RAW/'expanded200.csv',encoding='utf-8-sig')
assert df.shape==(24,8) and expanded.shape==(200,8)
assert df.sample_id.is_unique and expanded.sample_id.is_unique
assert not df.isna().any().any() and not expanded.isna().any().any()
assert expanded.response.sum()==62
corr=[]
for name,part in [('all',df),('treatment',df.loc[df.group=='treatment'])]:
 p=stats.pearsonr(part.dose,part.ALT);s=stats.spearmanr(part.dose,part.ALT)
 corr.append(dict(scope=name,n=len(part),pearson=p.statistic,pearson_p=p.pvalue,spearman=s.statistic,spearman_p=s.pvalue))
pd.DataFrame(corr).to_csv(OUT/'correlations.csv',index=False)
simple=sm.OLS(df.ALT,sm.add_constant(df[['dose']])).fit()
adjusted=df.assign(group_treatment=(df.group=='treatment').astype(int))
fit=sm.OLS(df.ALT,sm.add_constant(adjusted[['dose','age','group_treatment']])).fit()
rows=[]
for name,m in [('simple',simple),('adjusted',fit)]:
 for term,value in m.params.items():
  ci=m.conf_int().loc[term]
  rows.append(dict(model=name,term=term,estimate=value,ci_low=ci.iloc[0],ci_high=ci.iloc[1],p_value=m.pvalues[term],r_squared=m.rsquared))
pd.DataFrame(rows).to_csv(OUT/'linear_coefficients.csv',index=False)
diagnostics=df[['sample_id','dose','ALT']].copy()
diagnostics['fitted']=simple.fittedvalues;diagnostics['residual']=simple.resid
diagnostics['cooks_distance']=simple.get_influence().cooks_distance[0]
diagnostics.to_csv(OUT/'linear_diagnostics.csv',index=False)
fig,axes=plt.subplots(1,3,figsize=(13,4))
for group,part in df.groupby('group'):
 axes[0].scatter(part.dose,part.ALT,label=group)
axes[0].set(xlabel='dose (teaching unit)',ylabel='ALT (U/L)');axes[0].legend()
axes[1].scatter(simple.fittedvalues,simple.resid);axes[1].axhline(0,color='gray')
axes[1].set(xlabel='Fitted ALT (U/L)',ylabel='Residual (U/L)')
sm.qqplot(simple.resid,line='s',ax=axes[2]);fig.tight_layout();fig.savefig(OUT/'scatter_residuals.png',dpi=180);plt.close(fig)
X=sm.add_constant(expanded[['ALT','AST','age']]);logit=sm.Logit(expanded.response,X).fit(disp=False)
prob=logit.predict(X)
pd.DataFrame({'sample_id':expanded.sample_id,'response':expanded.response,'probability':prob}).to_csv(OUT/'probabilities.csv',index=False)
rows=[]
for threshold in [0.3,0.5,0.7]:
 pred=(prob>=threshold).astype(int);tn,fp,fn,tp=confusion_matrix(expanded.response,pred,labels=[0,1]).ravel()
 rows.append(dict(threshold=threshold,TN=int(tn),FP=int(fp),FN=int(fn),TP=int(tp),accuracy=(tp+tn)/len(pred),sensitivity=tp/(tp+fn),specificity=tn/(tn+fp),PPV=tp/(tp+fp) if tp+fp else np.nan,NPV=tn/(tn+fn) if tn+fn else np.nan))
pd.DataFrame(rows).to_csv(OUT/'threshold_results.csv',index=False)
fpr,tpr,_=roc_curve(expanded.response,prob,pos_label=1);auc=roc_auc_score(expanded.response,prob)
fig,ax=plt.subplots(figsize=(5,4));ax.plot(fpr,tpr,label=f'AUC={auc:.3f}');ax.plot([0,1],[0,1],'--',color='gray');ax.set(xlabel='False positive rate',ylabel='Sensitivity',title='Current fitted teaching data');ax.legend();fig.tight_layout();fig.savefig(OUT/'roc.png',dpi=180);plt.close(fig)
pd.DataFrame({'term':logit.params.index,'estimate':logit.params.values,'OR':np.exp(logit.params.values)}).to_csv(OUT/'logistic_coefficients.csv',index=False)
print(pd.DataFrame(corr).round(6).to_string(index=False));print(pd.DataFrame(rows).round(6).to_string(index=False));print(f'Fitted-data AUC={auc:.6f}')
