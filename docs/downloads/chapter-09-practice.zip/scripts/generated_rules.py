import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
from statsmodels.stats.diagnostic import het_breuschpagan
from sklearn.metrics import confusion_matrix, roc_auc_score


def make_base_data() -> pd.DataFrame:
    return pd.DataFrame({
        "sample_id": [f"S{i:02d}" for i in range(1, 25)],
        "group": ["control"] * 12 + ["treatment"] * 12,
        "dose": [0] * 12 + [5, 5, 10, 10, 15, 15, 20, 20, 25, 25, 30, 30],
        "ALT": [42, 38, 45, 51, 39, 48, 44, 55, 41, 47, 50, 43,
                35, 33, 40, 37, 31, 39, 36, 42, 34, 38, 41, 32],
        "AST": [35, 36, 32, 41, 38, 34, 40, 37, 39, 33, 42, 36,
                34, 33, 35, 37, 31, 36, 38, 32, 40, 35, 34, 33],
        "age": [46, 52, 41, 59, 48, 55, 44, 62, 50, 57, 53, 45,
                43, 49, 39, 58, 47, 54, 42, 60, 51, 56, 52, 44],
        "sex": ["F", "M"] * 12,
        "response": [0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0,
                     1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1],
    })


def make_expanded_data(n: int = 200) -> pd.DataFrame:
    i = np.arange(1, n + 1)
    dose_values = np.array([0, 5, 10, 15, 20, 25, 30, 35])
    dose = dose_values[(i - 1) % len(dose_values)]
    group_num = (dose > 0).astype(int)
    group = np.where(group_num == 1, "treatment", "control")
    age = 35 + (7 * i) % 31
    sex = np.where(i % 2 == 0, "M", "F")

    alt_noise = np.array([-5, -3, -1, 0, 2, 4, 1, -2, 3])[(i - 1) % 9]
    ast_noise = np.array([-4, -2, 2, 0, 4, -3, 1])[(i - 1) % 7]
    alt = 54 - 0.28 * dose + 0.12 * (age - 50) + 0.8 * group_num + alt_noise
    ast = 35 - 0.10 * dose + 0.05 * (age - 50) + ast_noise

    linear_score = -0.3 - 0.24 * (alt - 48) + 0.15 * (ast - 34) + 0.10 * (age - 50)
    true_prob = 1 / (1 + np.exp(-linear_score))
    pseudo_uniform = (((37 * i) % 199) + 0.5) / 199
    response = (pseudo_uniform < true_prob).astype(int)

    return pd.DataFrame({
        "sample_id": [f"E{x:03d}" for x in i],
        "group": group,
        "dose": dose,
        "ALT": alt,
        "AST": ast,
        "age": age,
        "sex": sex,
        "response": response,
    })


def classification_metrics(y_true, probability, threshold):
    y_pred = (probability >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        "threshold": threshold,
        "TN": int(tn),
        "FP": int(fp),
        "FN": int(fn),
        "TP": int(tp),
        "accuracy": (tp + tn) / (tn + fp + fn + tp),
        "sensitivity": tp / (tp + fn),
        "specificity": tn / (tn + fp),
        "PPV": tp / (tp + fp) if (tp + fp) else np.nan,
        "NPV": tn / (tn + fn) if (tn + fn) else np.nan,
    }
