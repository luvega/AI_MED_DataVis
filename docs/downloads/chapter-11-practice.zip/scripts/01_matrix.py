from __future__ import annotations

import json
from io import StringIO
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy.cluster.hierarchy import dendrogram, fcluster, leaves_list, linkage
from scipy.spatial.distance import pdist, squareform
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler


DATA = """sample_id,group,batch,F1,F2,F3,F4,F5,F6
S1,A,B1,8,7,6,2,3,100
S2,A,B1,9,8,7,3,2,110
S3,A,B2,8,9,6,4,5,1000
S4,A,B2,7,8,7,3,4,1010
S5,B,B1,3,2,2,8,7,105
S6,B,B1,2,3,3,9,8,115
S7,B,B2,4,5,3,8,9,1005
S8,B,B2,3,4,2,7,8,1015
"""


def as_mapping(index: pd.Index, labels: np.ndarray) -> dict[str, int]:
    return {str(sample): int(label) for sample, label in zip(index, labels)}


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    output_dir = root / "outputs"
    output_dir.mkdir(parents=True, exist_ok=True)

    frame = pd.read_csv(root / "data" / "raw" / "teaching_matrix.csv", encoding="utf-8-sig").set_index("sample_id")
    metadata = frame[["group", "batch"]].copy()
    matrix = frame.filter(regex=r"^F").copy()

    assert matrix.index.is_unique
    assert metadata.index.is_unique
    assert matrix.index.equals(metadata.index)
    assert matrix.notna().all().all()
    assert (matrix.std(axis=0) > 0).all()

    scaler = StandardScaler()
    scaled = pd.DataFrame(
        scaler.fit_transform(matrix), index=matrix.index, columns=matrix.columns
    )

    raw_pca = PCA().fit(matrix)
    scaled_pca = PCA().fit(scaled)
    raw_scores = pd.DataFrame(
        raw_pca.transform(matrix)[:, :2],
        index=matrix.index,
        columns=["PC1", "PC2"],
    )
    scaled_scores = pd.DataFrame(
        scaled_pca.transform(scaled)[:, :2],
        index=matrix.index,
        columns=["PC1", "PC2"],
    )
    loadings = pd.DataFrame(
        scaled_pca.components_[:2].T,
        index=matrix.columns,
        columns=["PC1", "PC2"],
    )

    distance_demo = pd.DataFrame(
        [[1, 2, 3, 4], [2, 4, 6, 8], [4, 3, 2, 1]],
        index=["P1", "P2", "P3"],
        columns=["T1", "T2", "T3", "T4"],
        dtype=float,
    )
    euclidean_demo = pd.DataFrame(
        squareform(pdist(distance_demo, metric="euclidean")),
        index=distance_demo.index,
        columns=distance_demo.index,
    )
    correlation_demo = pd.DataFrame(
        squareform(pdist(distance_demo, metric="correlation")),
        index=distance_demo.index,
        columns=distance_demo.index,
    )

    hierarchical: dict[str, dict[str, object]] = {}
    for data_name, data in {"raw": matrix, "scaled": scaled}.items():
        for metric in ("euclidean", "correlation"):
            distances = pdist(data, metric=metric)
            for method in ("complete", "average", "single"):
                tree = linkage(distances, method=method)
                labels = fcluster(tree, t=2, criterion="maxclust")
                key = f"{data_name}_{metric}_{method}"
                hierarchical[key] = {
                    "clusters": as_mapping(matrix.index, labels),
                    "leaf_order": [str(x) for x in matrix.index[leaves_list(tree)]],
                }

    kmeans: dict[str, dict[str, object]] = {}
    for k in (2, 3):
        fit = KMeans(n_clusters=k, random_state=42, n_init=20).fit(scaled)
        kmeans[f"k{k}"] = {
            "clusters": as_mapping(matrix.index, fit.labels_ + 1),
            "inertia": float(fit.inertia_),
        }

    pca_table = scaled_scores.join(metadata)
    pca_table.to_csv(output_dir / "teaching_case_pca_scores.csv", encoding="utf-8-sig")
    loadings.to_csv(output_dir / "teaching_case_pca_loadings.csv", encoding="utf-8-sig")
    scaled.to_csv(output_dir / "teaching_case_zscore_matrix.csv", encoding="utf-8-sig")

    palette = {"A": "#0072B2", "B": "#D55E00"}
    markers = {"B1": "o", "B2": "s"}
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.2), constrained_layout=True)
    for ax, scores, fitted, title in (
        (axes[0], raw_scores, raw_pca, "PCA before standardization"),
        (axes[1], scaled_scores, scaled_pca, "PCA after feature z-score"),
    ):
        for sample in scores.index:
            ax.scatter(
                scores.loc[sample, "PC1"],
                scores.loc[sample, "PC2"],
                color=palette[metadata.loc[sample, "group"]],
                marker=markers[metadata.loc[sample, "batch"]],
                s=55,
            )
            ax.text(
                scores.loc[sample, "PC1"],
                scores.loc[sample, "PC2"],
                f" {sample}",
                fontsize=8,
            )
        ax.set_title(title)
        ax.set_xlabel(f"PC1 ({fitted.explained_variance_ratio_[0] * 100:.1f}%)")
        ax.set_ylabel(f"PC2 ({fitted.explained_variance_ratio_[1] * 100:.1f}%)")
        ax.axhline(0, color="#BBBBBB", linewidth=0.7)
        ax.axvline(0, color="#BBBBBB", linewidth=0.7)
    fig.savefig(output_dir / "fig11_teaching_case_pca.png", dpi=200)
    plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(12, 4), constrained_layout=True)
    scaled_dist = pdist(scaled, metric="euclidean")
    for ax, method in zip(axes, ("complete", "average", "single")):
        dendrogram(linkage(scaled_dist, method=method), labels=matrix.index, ax=ax)
        ax.set_title(f"{method} linkage")
        ax.set_ylabel("merge height")
    fig.savefig(output_dir / "fig11_teaching_case_dendrograms.png", dpi=200)
    plt.close(fig)

    group_colors = metadata["group"].map(palette)
    batch_palette = {"B1": "#009E73", "B2": "#CC79A7"}
    batch_colors = metadata["batch"].map(batch_palette)
    col_colors = pd.DataFrame({"group": group_colors, "batch": batch_colors})
    heatmap = sns.clustermap(
        scaled.T,
        method="average",
        metric="euclidean",
        cmap="vlag",
        center=0,
        col_colors=col_colors,
        figsize=(8, 6),
    )
    heatmap.ax_heatmap.set_xlabel("sample")
    heatmap.ax_heatmap.set_ylabel("feature")
    heatmap.savefig(output_dir / "fig11_teaching_case_heatmap.png", dpi=200)
    plt.close(heatmap.fig)

    result = {
        "shape": [int(matrix.shape[0]), int(matrix.shape[1])],
        "metadata_match": bool(matrix.index.equals(metadata.index)),
        "raw_pca_pve": [float(x) for x in raw_pca.explained_variance_ratio_[:4]],
        "scaled_pca_pve": [float(x) for x in scaled_pca.explained_variance_ratio_[:4]],
        "scaled_pca_scores": scaled_scores.round(3).to_dict(orient="index"),
        "scaled_pca_loadings": loadings.round(3).to_dict(orient="index"),
        "distance_demo_euclidean": euclidean_demo.round(3).to_dict(orient="index"),
        "distance_demo_correlation": correlation_demo.round(3).to_dict(orient="index"),
        "hierarchical": hierarchical,
        "kmeans": kmeans,
    }
    (output_dir / "teaching_case_results.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(f"shape={matrix.shape}")
    print(f"metadata_match={matrix.index.equals(metadata.index)}")
    print("raw_pca_pve=" + np.array2string(raw_pca.explained_variance_ratio_[:4], precision=4))
    print("scaled_pca_pve=" + np.array2string(scaled_pca.explained_variance_ratio_[:4], precision=4))
    print("scaled_pca_scores")
    print(scaled_scores.round(3).to_string())
    print("scaled_pca_loadings")
    print(loadings.round(3).to_string())
    print("distance_demo_euclidean")
    print(euclidean_demo.round(3).to_string())
    print("distance_demo_correlation")
    print(correlation_demo.round(3).to_string())
    print("hierarchical_scaled_euclidean_complete")
    print(hierarchical["scaled_euclidean_complete"])
    print("hierarchical_raw_euclidean_complete")
    print(hierarchical["raw_euclidean_complete"])
    print("kmeans")
    print(json.dumps(kmeans, ensure_ascii=False, indent=2))
    print(f"artifacts={output_dir}")


if __name__ == "__main__":
    main()
