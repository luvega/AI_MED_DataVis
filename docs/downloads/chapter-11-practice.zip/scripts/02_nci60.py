"""读取已核验的NCI60本地表；标签只在拟合后使用。"""
from pathlib import Path
import json
import platform
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
from scipy.cluster.hierarchy import linkage,cut_tree
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_rand_score
from sklearn.preprocessing import StandardScaler
ROOT=Path(__file__).resolve().parents[1];RAW=ROOT/'data/raw';OUT=ROOT/'outputs';OUT.mkdir(exist_ok=True)
X=pd.read_csv(RAW/'nci60_matrix.csv.gz',compression='gzip')
metadata=pd.read_csv(RAW/'nci60_labels.csv')
assert X.shape==(64,6830) and len(metadata)==64
assert metadata.row_index.tolist()==list(range(1,65))
assert np.isfinite(X.to_numpy()).all() and (X.std(axis=0)>0).all()
Z=StandardScaler().fit_transform(X)
pca=PCA(svd_solver='full');scores=pca.fit_transform(Z)
pve=pd.DataFrame({'principal_component':np.arange(1,len(pca.explained_variance_ratio_)+1),'pve':pca.explained_variance_ratio_,'cumulative_pve':np.cumsum(pca.explained_variance_ratio_)})
pve.to_csv(OUT/'nci60_pve.csv',index=False)
assignments=metadata.copy()
for method in ['complete','average','single']:
 tree=linkage(Z,method=method,metric='euclidean')
 assignments[method]=cut_tree(tree,n_clusters=4).ravel()
kmeans=KMeans(n_clusters=4,n_init=20,random_state=0).fit(Z)
assignments['kmeans_k4']=kmeans.labels_
assignments['first5pc']=cut_tree(linkage(scores[:,:5],method='complete'),n_clusters=4).ravel()
assignments.to_csv(OUT/'nci60_clusters.csv',index=False)
pd.crosstab(assignments.complete,assignments.kmeans_k4).to_csv(OUT/'nci60_hclust_kmeans.csv')
pd.crosstab(assignments.label,assignments.complete).to_csv(OUT/'nci60_labels_clusters.csv')
result={'shape':list(X.shape),'python':platform.python_version(),'sklearn':sklearn.__version__,'first3_pve':pve.pve[:3].tolist(),'first7_pve':float(pve.pve[:7].sum()),'cluster_sizes':{m:sorted(assignments[m].value_counts().tolist(),reverse=True) for m in ['complete','average','single','kmeans_k4']},'full_vs_5pc_ari':float(adjusted_rand_score(assignments.complete,assignments.first5pc))}
(OUT/'nci60_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
fig,axes=plt.subplots(1,2,figsize=(10,4))
for label,part in metadata.groupby('label'):
 idx=part.index.to_numpy();axes[0].scatter(scores[idx,0],scores[idx,1],s=22,label=label)
axes[0].set(xlabel=f'PC1 ({pve.pve.iloc[0]*100:.2f}%)',ylabel=f'PC2 ({pve.pve.iloc[1]*100:.2f}%)');axes[0].legend(fontsize=6,ncol=2)
axes[1].plot(pve.principal_component[:15],pve.pve[:15],marker='o');axes[1].plot(pve.principal_component[:15],pve.cumulative_pve[:15],marker='s');axes[1].set(xlabel='Principal component',ylabel='Variance proportion');fig.tight_layout();fig.savefig(OUT/'nci60_pca.png',dpi=180);plt.close(fig)
print(json.dumps(result,ensure_ascii=False,indent=2))
