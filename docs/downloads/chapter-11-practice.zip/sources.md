# 来源与许可

8×6矩阵为本教材既有教学构造，来自2026-07-10第11章教学案例，可随教材练习使用。NCI60表来自本项目2026-07-16用ISLP/ISLR核验并保存的本地导出，64×6830矩阵和标签在原核验中逐项对齐。包内保留固定输入，演示读取CSV，不依赖在线服务。

原始教材与数据接口

- https://www.statlearning.com/
- https://islp.readthedocs.io/en/latest/datasets/NCI60.html
- https://cran.r-project.org/package=ISLR

NCI60为教学数据中的癌细胞系表达特征，附带既有癌种标签。保持出处与该数据集身份，不将其改写成课程自采患者数据。Python和R程序由本教材既有分析派生。标签未进入PCA和聚类拟合。

本机ISLR 1.4的DESCRIPTION明确标示License: GPL-2。本包保留COPYING-R.txt的GNU许可文本及教材数据出处；data/raw为已对齐的NCI60教材表导出。
