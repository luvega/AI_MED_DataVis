# 数据字典

| 文件 | 行列与字段 |
| --- | --- |
| teaching_matrix.csv | 8行；sample_id、group、batch与F1—F6。F1—F6为教学构造数值，无真实生物单位；group和batch是元数据 |
| nci60_matrix.csv.gz | 64行细胞系，6830列表达特征，列名1—6830为保留位置编号，不当作基因符号；gzip内UTF-8 CSV |
| nci60_labels.csv | row_index从1到64，与矩阵当前行顺序一一对应；label为既有癌种标签，拟合后用于对照 |

模型输入为样本×特征。PCA scores每行样本，loadings每行特征。热图将教学矩阵转置为特征×样本，颜色为按特征计算的z-score。Python StandardScaler采用总体SD口径；基础R演示按相同口径处理小矩阵；NCI60 prcomp样本SD只形成统一尺度因子，PVE不变。
