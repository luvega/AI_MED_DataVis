# 第11章 高维矩阵、PCA、聚类与热图练习包

本包对应11.1—11.6。先运行8×6教学矩阵，观察F6量级、标准化、距离与聚类如何改变结果，再读取NCI60的64×6830真实细胞系表达矩阵。全部输入在本地，不需要安装ISLP或ISLR来下载数据。

```text
python scripts/01_matrix.py
python scripts/02_nci60.py
Rscript scripts/03_matrix.R
```

Python需要numpy、pandas、scipy、scikit-learn、matplotlib、seaborn；R演示只需随附包。先安装环境再上课。脚本按文件位置寻找data/raw，结果统一写入outputs。预测小矩阵的主变化方向，运行并核对PVE、成员关系和载荷，再按exercises.md只改变一个条件。

数据说明见data_dictionary.md，来源及许可见sources.md。scripts/01_matrix.py保存原教学构造规则，并读取固定CSV输入；运行不会修改原数据。保留实际软件版本和输出，PCA符号及k-means成员差异按正文解释。
