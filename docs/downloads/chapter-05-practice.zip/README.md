# 第5章读取与质量练习

在解压后的本包根目录打开终端，先确认能看到data、scripts和outputs。安装requirements.txt所列依赖后依次运行

```powershell
python scripts/01_read_files.py
python scripts/02_inventory_quality.py
python scripts/03_guesses_quality.py
Rscript scripts/03_guesses_quality.R
```

01对应5.1—5.2，核对6×8实验表、工作表和编码副本。02对应5.3—5.6，库存构造表25行，库存任务保留23行；重复候选只标记，单价缺失保留。03对应糖豆主案例，原14条记录、确认副本处理后13条、可数值化9条。R脚本仅需基础R，与Python核对记录号、数量及数值。完整来源、字典及独立任务见本包同名文件。运行结果均写入outputs。
