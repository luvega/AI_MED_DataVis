from pathlib import Path
import pandas as pd
BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'outputs'
OUT.mkdir(exist_ok=True)

raw = pd.read_csv(BASE/'data/raw/lolamicin_2_8h.csv', dtype={'treatment':'string'}, encoding='utf-8')
assert raw.shape == (6,8)
print('记录与字段', raw.shape)
print('列名',raw.columns.tolist())
book = pd.ExcelFile(BASE/'data/raw/lolamicin_tables.xlsx')
print('工作表', book.sheet_names)
excel = pd.read_excel(book, sheet_name='long_records')
pd.testing.assert_frame_equal(raw, excel, check_dtype=False)
a = pd.read_csv(BASE/'data/raw/wide_utf8.csv', encoding='utf-8')
b = pd.read_csv(BASE/'data/raw/wide_gb18030.csv', encoding='gb18030')
pd.testing.assert_frame_equal(a,b)
raw.to_csv(OUT/'readback.csv',index=False)
again = pd.read_csv(OUT/'readback.csv')
pd.testing.assert_frame_equal(raw,again,check_dtype=False)
print('指定CSV/Excel和编码副本核对通过；导出回读',again.shape)
