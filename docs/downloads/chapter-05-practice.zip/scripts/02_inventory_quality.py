from pathlib import Path
import pandas as pd
BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'outputs'
OUT.mkdir(exist_ok=True)

raw = pd.read_csv(BASE/'data/raw/inventory_teaching.csv',encoding='utf-8-sig',dtype=str,keep_default_na=False)
work = raw.copy()
work['stock_num'] = pd.to_numeric(work['Stock_Qty'],errors='coerce')
missing = work['Stock_Qty'].eq('')
invalid = work['Stock_Qty'].ne('') & work['stock_num'].isna()
negative = work['stock_num'].lt(0)
keys = ['Drug_Name','Stock_Qty','Expiry_Date','Supplier']
candidate = work.duplicated(keys,keep=False)
work['expiry_parsed'] = pd.to_datetime(work['Expiry_Date'],format='mixed',errors='coerce')
issues=[]
for label,mask in [('missing_stock',missing),('invalid_stock',invalid),('negative_stock',negative),('duplicate_candidate',candidate)]:
    for rid in work.loc[mask,'Drug_ID']:
        issues.append({'Drug_ID':rid,'issue':label,'action':'review' if label=='duplicate_candidate' else 'exclude_from_stock_summary'})
for label,mask in [('missing_price',work['Unit_Price_CNY'].eq('')),
                   ('missing_supplier',work['Supplier'].eq('')),
                   ('invalid_expiry',work['expiry_parsed'].isna())]:
    for rid in work.loc[mask,'Drug_ID']:
        issues.append({'Drug_ID':rid,'issue':label,'action':'retain_for_stock_review_related_task'})
eligible = ~(missing | invalid | negative)
analysis = work.loc[eligible].copy()
# 单价缺失不影响库存数量任务。候选重复缺少批次依据，保留并标记。
analysis['duplicate_candidate'] = candidate.loc[eligible]
pd.DataFrame(issues,columns=['Drug_ID','issue','action']).to_csv(OUT/'inventory_issues.csv',index=False)
analysis.to_csv(OUT/'inventory_analysis.csv',index=False)
pd.DataFrame([{'stage':'raw','records':len(raw)},{'stage':'stock_eligible','records':len(analysis)}]).to_csv(OUT/'inventory_flow.csv',index=False)
assert len(raw)==25 and len(analysis)==23
assert set(work.loc[missing,'Drug_ID'])=={'D017'}
assert set(work.loc[negative,'Drug_ID'])=={'D018'}
assert set(work.loc[candidate,'Drug_ID'])=={'D002','D016'}
assert work.loc[work['Stock_Qty'].eq('0'),'stock_num'].eq(0).all()
assert eligible.loc[work['Stock_Qty'].eq('0')].all()
print('原始记录',len(raw),'库存可汇总记录',len(analysis),'库存合计',analysis['stock_num'].sum())
print(pd.DataFrame(issues).to_string(index=False))
