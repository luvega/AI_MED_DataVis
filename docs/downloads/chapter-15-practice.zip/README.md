# 第15章学生练习：空间邻接、模态对齐与项目审阅

基础入口使用100个构造spot的10×10网格以及独立构造RNA/ADT标识表，练习空间图、参数变化、顺序对齐和混杂识别。真实Visium、CITE和TCR结果另以2026-07-16已保存小表提供；网格运行不会重新产生这些真实结果。正文仍详细讲解原整合、拟时序、velocity、通讯和多模态案例。

```powershell
python scripts/01_grid_analysis.py
python scripts/02_alignment_and_reference.py
```

需要numpy、pandas、matplotlib，输入全在本地，不访问付费API或个人账户。第一项保存Moran统计、连边计数、置换Z与三联图；第二项保存RNA/ADT交集、缺失列表、按ID重排结果、batch×condition表和已保存结果字段审阅。

先用一个角点和一个内部点手数邻居，再预测整个四邻接图的连边数。运行后将`--neighbors queen`改成八邻接，记录连边和Moran统计变化。网格Moran可与data/raw中的旧教学值核对；Z分数的置换实现与旧Squidpy不同，先比较构造区域及方向，不承诺逐项相同。

真实大对象、深度学习整合、拟时序、RNA velocity、细胞通讯与完整AIRR管线属于拓展，基础包没有重新运行它们；来源与准备条件见sources。项目填写records中的任务说明书、图注与贡献记录，独立任务见exercises。
