# 数据字典

| 文件或字段 | 观察单位与含义 | 状态 |
| --- | --- | --- |
| constructed_grid.csv | 100个构造spot；x/y规则网格；A/B/C三竖向区域；两特征无生物学单位 | 独立构造；固定NumPy种子20260710、float32 |
| 教学网格-MoranI/邻域富集Z分数.csv | 2026-07-10既有Squidpy输出 | 已保存构造结果，区别本轮NumPy置换 |
| constructed_rna_cells.csv | 5细胞；sample/donor/batch/condition/cell_type | 独立构造且batch与condition完全混杂 |
| constructed_adt_cells.csv | 4细胞；供体、样本和ADT教学计数 | 独立构造；顺序打乱且各模态有未匹配ID |
| Visium-MoransI.csv | Nrgn/Ttr空间自相关及置换统计 | 单切片2,688spot既有真实结果 |
| Visium-邻接敏感性.csv | n_rings1/2的连边及富集矩阵比较 | 2026-07-16既有结果 |
| CITE-seq-供者质控汇总.csv | 供者内两阶段ADT过滤数量和分布 | 12供者既有汇总，不是本轮大对象重算 |
| AIRR-TCR链质控.csv | 细胞级链配对类别与数量 | 既有Scirpy结果，不解释抗原特异性 |
