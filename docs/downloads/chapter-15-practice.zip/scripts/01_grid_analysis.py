"""本地构造网格的透明矩阵计算；非真实空间组学再现。"""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];out=ROOT/"outputs";out.mkdir(exist_ok=True)
parser=argparse.ArgumentParser();parser.add_argument("--neighbors",choices=["rook","queen"],default="rook");parser.add_argument("--permutations",type=int,default=200);args=parser.parse_args()
assert args.permutations>=20
grid=pd.read_csv(ROOT/"data/raw/constructed_grid.csv")
assert len(grid)==100 and grid.spot_id.is_unique and grid[["x","y"]].drop_duplicates().shape[0]==100
coordinates=grid[["x","y"]].to_numpy();d=np.abs(coordinates[:,None,:]-coordinates[None,:,:])
adj=(d.sum(axis=2)==1) if args.neighbors=="rook" else ((d.max(axis=2)==1)&(d.sum(axis=2)>0))
assert np.array_equal(adj,adj.T) and not np.diag(adj).any()
weights=adj/adj.sum(axis=1,keepdims=True)
def moran(values):
    z=values-values.mean();return len(z)/weights.sum()*(z@(weights@z))/(z@z)
moran_rows=[{"feature":g,"I":float(moran(grid[g].to_numpy()))} for g in ["gene_gradient","gene_noise"]]
pd.DataFrame(moran_rows).to_csv(out/"grid_moran.csv",index=False)
labels=pd.Categorical(grid.region,categories=["A","B","C"]).codes
i,j=np.where(adj)
def edge_count(labs):
    return np.bincount(labs[i]*3+labs[j],minlength=9).reshape(3,3)
observed=edge_count(labels);rng=np.random.default_rng(20260710)
null=np.asarray([edge_count(rng.permutation(labels)) for _ in range(args.permutations)])
sd=null.std(axis=0);z=np.divide(observed-null.mean(axis=0),sd,out=np.full((3,3),np.nan),where=sd>0)
pd.DataFrame(observed,index=["A","B","C"],columns=["A","B","C"]).to_csv(out/"grid_neighbor_counts.csv")
pd.DataFrame(z,index=["A","B","C"],columns=["A","B","C"]).to_csv(out/"grid_neighbor_z.csv")
record={"status":"constructed_grid_independent_numpy_computation","spots":len(grid),"directed_nonzero_edges":int(adj.sum()),"neighbors":args.neighbors,"weights":"row_standardized_for_Moran","permutations":args.permutations,"seed":20260710,"moran":moran_rows,"permutation_note":"Independent NumPy permutation stream; cached Squidpy Z scores use a separate implementation."}
(out/"grid_run.json").write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding="utf-8")
fig,axes=plt.subplots(1,3,figsize=(13,4))
for ax,g in zip(axes[:2],["gene_gradient","gene_noise"]):
    points=ax.scatter(grid.x,grid.y,c=grid[g],cmap="viridis",s=35);ax.set(title=g,xlabel="x",ylabel="y",aspect="equal");fig.colorbar(points,ax=ax,shrink=.8)
im=axes[2].imshow(z,cmap="coolwarm");axes[2].set(xticks=range(3),yticks=range(3),xticklabels=["A","B","C"],yticklabels=["A","B","C"],title=args.neighbors+" neighborhood Z");fig.colorbar(im,ax=axes[2],shrink=.8)
fig.savefig(out/"grid_spatial_and_neighbors.png",dpi=180,bbox_inches="tight");plt.close(fig)
print(json.dumps(record,ensure_ascii=False,indent=2))
