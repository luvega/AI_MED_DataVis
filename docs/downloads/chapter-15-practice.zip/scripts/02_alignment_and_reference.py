"""构造RNA/ADT ID对齐、混杂核对与已保存真实结果审阅。"""
from pathlib import Path
import json
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];out=ROOT/"outputs";out.mkdir(exist_ok=True)
rna=pd.read_csv(ROOT/"data/raw/constructed_rna_cells.csv").set_index("cell_id")
adt=pd.read_csv(ROOT/"data/raw/constructed_adt_cells.csv").set_index("cell_id")
assert rna.index.is_unique and adt.index.is_unique
common=rna.index.intersection(adt.index,sort=False)
rna_aligned=rna.loc[common];adt_aligned=adt.loc[common]
assert rna_aligned.index.equals(adt_aligned.index)
assert rna_aligned.donor.equals(adt_aligned.donor)
joined=rna_aligned.join(adt_aligned[["adt_total"]],validate="one_to_one")
joined.to_csv(out/"constructed_paired_cells.csv",encoding="utf-8-sig")
cross=pd.crosstab(rna.batch,rna.condition);cross.to_csv(out/"constructed_batch_condition.csv")
record={"mode":"constructed_alignment_plus_saved_reference_review","rna_before":len(rna),"adt_before":len(adt),"paired_after":len(common),"rna_only":rna.index.difference(common).tolist(),"adt_only":adt.index.difference(common).tolist(),"matching_order":True,"batch_condition_complete_confounding":bool(cross.gt(0).sum(axis=1).eq(1).all() and cross.gt(0).sum(axis=0).eq(1).all())}
for f in ["Visium-MoransI.csv","Visium-邻接敏感性.csv","CITE-seq-供者质控汇总.csv","AIRR-TCR链质控.csv"]:
    table=pd.read_csv(ROOT/"data/raw"/f);record[f]={"status":"saved_course_2026-07-16_results","rows":len(table),"columns":table.columns.tolist()}
(out/"alignment_reference_audit.json").write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding="utf-8");print(json.dumps(record,ensure_ascii=False,indent=2))
