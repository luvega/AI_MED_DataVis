# 第14章学生练习：对象、质控规则和参数变化

人骨髓案例仍是正文主案例。本包用SeuratObject公开小对象`pbmc_small`做独立迁移练习，计数为230个基因×80个细胞，不能把它写成人骨髓原对象。计数仅有一个特征子集，缺少完整空液滴、线粒体与供体层信息；另提供明确构造的6行QC表，单独练习规则标记和删行记录。

```powershell
python scripts/01_object_and_qc.py
python scripts/02_review_reference.py
```

Python入口需要pandas、matplotlib；第一项核对实际计数并练习构造QC，第二项重绘已保存坐标和四档resolution结果，不重新生成UMAP。核对材料为data/raw中的既有坐标、cluster计数和marker字段表。运行前预测细胞数及规则变化，运行后打开outputs中的表和图。

具备已安装Seurat环境时运行原生R流程：

```powershell
Rscript scripts/03_seurat.R
```

R脚本从本地计数重新建立对象，运行LogNormalize、vst特征选择、PCA、邻接图、四档resolution、UMAP和marker展示，保存真实矩阵与参数输出。需要Seurat、SeuratObject、ggplot2及其正常运行依赖，不会联网安装。骨髓远程对象、OSCA大对象与CellTypist模型未随基础包分发，参见sources中的拓展入口。

修改`--max-mt 15`先预测构造QC保留数，再运行；对实际pbmc_small的resolution变化使用不同输出文件，避免与缓存参考结果混写。完成exercises中的独立任务，填写records模板。
