#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(Seurat)
  library(ggplot2)
})

full_args <- commandArgs(trailingOnly=FALSE)
script_file <- sub("^--file=", "", full_args[grepl("^--file=", full_args)][1])
root <- normalizePath(file.path(dirname(script_file),".."),mustWork=TRUE)
out_dir <- file.path(root,"outputs")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

stage <- function(message) {
  cat(format(Sys.time(), "%H:%M:%S"), message, "\n")
  flush.console()
}

seed <- 20260710L
set.seed(seed)

stage("Loading pbmc_small and rebuilding the Seurat object")
counts <- as.matrix(read.csv(file.path(root,"data/raw/pbmc_small_counts.csv"),row.names=1,check.names=FALSE))
stopifnot(all(counts>=0),all(counts==floor(counts)))
storage.mode(counts) <- "integer"
obj <- CreateSeuratObject(
  counts = counts,
  project = "chapter14_pbmc_small",
  min.cells = 0,
  min.features = 0
)

obj <- NormalizeData(
  obj,
  normalization.method = "LogNormalize",
  scale.factor = 10000,
  verbose = FALSE
)
obj <- FindVariableFeatures(
  obj,
  selection.method = "vst",
  nfeatures = 200,
  verbose = FALSE
)
stage("Normalization and variable-feature selection completed")
write.csv(as.matrix(GetAssayData(obj,assay="RNA",layer="data")),file.path(out_dir,"native_normalized_expression.csv"))
obj <- ScaleData(obj, features = VariableFeatures(obj), verbose = FALSE)
obj <- RunPCA(
  obj,
  features = VariableFeatures(obj),
  npcs = 10,
  seed.use = seed,
  verbose = FALSE
)
obj <- FindNeighbors(obj, dims = 1:10, verbose = FALSE)
stage("PCA and neighbor graph completed")
obj <- RunUMAP(
  obj,
  dims = 1:10,
  seed.use = seed,
  verbose = FALSE
)
stage("UMAP completed")

resolutions <- c(0.2, 0.5, 0.8, 1.2)
resolution_columns <- character(length(resolutions))
cluster_counts <- vector("list", length(resolutions))

for (i in seq_along(resolutions)) {
  resolution <- resolutions[[i]]
  obj <- FindClusters(
    obj,
    resolution = resolution,
    random.seed = seed,
    verbose = FALSE
  )
  column <- paste0("RNA_snn_res.", resolution)
  if (!column %in% colnames(obj[[]])) {
    stop("Missing clustering metadata column: ", column)
  }
  resolution_columns[[i]] <- column
  tab <- table(obj[[column, drop = TRUE]])
  cluster_counts[[i]] <- data.frame(
    resolution = resolution,
    cluster = names(tab),
    n_cells = as.integer(tab),
    stringsAsFactors = FALSE
  )
}
stage("Resolution sweep completed")

cluster_counts <- do.call(rbind, cluster_counts)
write.csv(
  cluster_counts,
  file.path(out_dir, "chapter14_cluster_counts.csv"),
  row.names = FALSE
)

final_column <- "RNA_snn_res.0.8"
Idents(obj) <- obj[[final_column, drop = TRUE]]

umap <- Embeddings(obj, reduction = "umap")
umap_output <- data.frame(
  cell = rownames(umap),
  UMAP_1 = umap[, 1],
  UMAP_2 = umap[, 2],
  cluster_res_0_8 = as.character(Idents(obj)),
  stringsAsFactors = FALSE,
  check.names = FALSE
)
write.csv(
  umap_output,
  file.path(out_dir, "chapter14_umap_coordinates.csv"),
  row.names = FALSE
)

markers <- FindAllMarkers(
  obj,
  only.pos = TRUE,
  min.pct = 0.25,
  logfc.threshold = 0.25,
  verbose = FALSE
)
stage("Marker testing completed")
write.csv(
  markers,
  file.path(out_dir, "chapter14_marker_table.csv"),
  row.names = FALSE
)

hvg <- data.frame(
  rank = seq_along(VariableFeatures(obj)),
  gene = VariableFeatures(obj),
  stringsAsFactors = FALSE
)
write.csv(
  hvg,
  file.path(out_dir, "chapter14_highly_variable_features.csv"),
  row.names = FALSE
)

resolution_titles <- paste0("resolution = ", resolutions)
p_resolution <- DimPlot(
  obj,
  reduction = "umap",
  group.by = resolution_columns,
  label = TRUE,
  repel = TRUE,
  ncol = 2,
  pt.size = 1.4
)
for (i in seq_along(p_resolution)) {
  p_resolution[[i]] <- p_resolution[[i]] +
    ggtitle(resolution_titles[[i]]) +
    theme_bw(base_size = 11) +
    theme(
      panel.grid = element_blank(),
      legend.position = "right",
      plot.title = element_text(hjust = 0.5)
    )
}
ggsave(
  file.path(out_dir, "chapter14_seurat_resolution_umap.png"),
  plot = p_resolution,
  width = 10,
  height = 8,
  units = "in",
  dpi = 300,
  bg = "white"
)
stage("Resolution figure saved")

marker_panel <- c(
  "MS4A1", "CD79A", "CD3D", "CD3E", "CD14", "LYZ",
  "NKG7", "GNLY", "PPBP", "FCGR3A", "LST1"
)
marker_panel <- marker_panel[marker_panel %in% rownames(obj)]
p_markers <- DotPlot(
  obj,
  features = marker_panel,
  group.by = final_column
) +
  RotatedAxis() +
  labs(x = "marker gene", y = "cluster (resolution = 0.8)") +
  theme_bw(base_size = 11) +
  theme(panel.grid.minor = element_blank())
ggsave(
  file.path(out_dir, "chapter14_seurat_marker_dotplot.png"),
  plot = p_markers,
  width = 9,
  height = 5,
  units = "in",
  dpi = 300,
  bg = "white"
)
stage("Marker dot plot saved")

summary_table <- data.frame(
  item = c(
    "seed", "n_features", "n_cells", "n_variable_features", "n_pcs",
    "umap_rows", "umap_columns", "marker_rows", "mt_gene_count",
    "R", "Seurat", "SeuratObject", "uwot", "ggplot2"
  ),
  value = c(
    seed,
    nrow(obj),
    ncol(obj),
    length(VariableFeatures(obj)),
    ncol(Embeddings(obj, reduction = "pca")),
    nrow(umap),
    ncol(umap),
    nrow(markers),
    sum(grepl("^MT-", rownames(obj))),
    as.character(getRversion()),
    as.character(packageVersion("Seurat")),
    as.character(packageVersion("SeuratObject")),
    as.character(packageVersion("uwot")),
    as.character(packageVersion("ggplot2"))
  ),
  stringsAsFactors = FALSE
)
write.csv(
  summary_table,
  file.path(out_dir, "chapter14_run_summary.csv"),
  row.names = FALSE
)

session_path <- file.path(out_dir, "chapter14_session_info.txt")
sink(session_path)
cat("Chapter 14 Seurat pbmc_small teaching run\n")
cat("Generated:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"), "\n")
cat("Seed:", seed, "\n\n")
print(sessionInfo())
sink()

cat("Run completed.\n")
cat("Object:", nrow(obj), "features x", ncol(obj), "cells\n")
cat("Variable features:", length(VariableFeatures(obj)), "\n")
cat("UMAP:", nrow(umap), "x", ncol(umap), "\n")
cat("Marker rows:", nrow(markers), "\n")
print(cluster_counts, row.names = FALSE)
