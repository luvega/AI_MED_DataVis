"""实际pbmc_small计数核对与独立构造QC规则练习。"""
from pathlib import Path
import argparse,json
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];out=ROOT/"outputs";out.mkdir(exist_ok=True)
parser=argparse.ArgumentParser();parser.add_argument("--max-mt",type=float,default=20);args=parser.parse_args()
counts=pd.read_csv(ROOT/"data/raw/pbmc_small_counts.csv").set_index("gene_id")
assert counts.index.is_unique and counts.columns.is_unique
assert counts.ge(0).all().all() and counts.eq(counts.astype(int)).all().all()
observed=pd.DataFrame({"cell_id":counts.columns,"total_counts_in_subset":counts.sum().to_numpy(),"detected_genes_in_subset":counts.gt(0).sum().to_numpy()})
observed.to_csv(out/"pbmc_small_object_metrics.csv",index=False,encoding="utf-8-sig")
qc=pd.read_csv(ROOT/"data/raw/constructed_qc.csv")
qc["low_genes"]=qc.n_genes.lt(200);qc["high_mt"]=qc.pct_mt.gt(args.max_mt)
qc["keep"]=~(qc.low_genes|qc.high_mt)
qc.to_csv(out/"constructed_qc_flags.csv",index=False,encoding="utf-8-sig")
summary={"counts_status":"SeuratObject_pbmc_small_subset","genes":len(counts),"cells":counts.shape[1],"mt_features":int(counts.index.str.startswith("MT-").sum()),"qc_input_status":"independent_constructed_six_cells","max_mt":args.max_mt,"qc_before":len(qc),"qc_low_genes":int(qc.low_genes.sum()),"qc_high_mt":int(qc.high_mt.sum()),"qc_retained":int(qc.keep.sum())}
(out/"object_qc_summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8");print(json.dumps(summary,ensure_ascii=False,indent=2))
