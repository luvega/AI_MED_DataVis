"""绘制已保存Seurat坐标与resolution计数；不重算UMAP。"""
from pathlib import Path
import json
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];out=ROOT/"outputs";out.mkdir(exist_ok=True)
coords=pd.read_csv(ROOT/"data/raw/chapter14_umap_coordinates.csv")
groups=pd.read_csv(ROOT/"data/raw/chapter14_cluster_counts.csv")
assert len(coords)==80 and coords.cell.is_unique
assert groups.groupby("resolution").n_cells.sum().eq(80).all()
summary=groups.groupby("resolution").agg(n_clusters=("cluster","count"),n_cells=("n_cells","sum")).reset_index()
summary.to_csv(out/"reference_resolution_summary.csv",index=False)
fig,axes=plt.subplots(1,2,figsize=(10,4))
axes[0].scatter(coords.UMAP_1,coords.UMAP_2,c=coords.cluster_res_0_8,s=20,cmap="tab10")
axes[0].set(xlabel="UMAP1",ylabel="UMAP2",title="Saved Seurat UMAP; resolution 0.8")
axes[1].plot(summary.resolution,summary.n_clusters,marker="o")
axes[1].set(xlabel="resolution",ylabel="cluster count",title="Same 80 cells, changed granularity")
fig.savefig(out/"reference_parameter_review.png",dpi=180,bbox_inches="tight");plt.close(fig)
record={"mode":"offline_review_of_saved_2026-07-10_Seurat_results","coordinate_rows":len(coords),"resolution_results":summary.to_dict("records")}
(out/"reference_review.json").write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding="utf-8");print(json.dumps(record,ensure_ascii=False,indent=2))
