# 数据字典

| 文件或字段 | 对象含义与单位 | 状态 |
| --- | --- | --- |
| pbmc_small_counts.csv | 基因×细胞；非负整数计数，230×80 | SeuratObject公开示例对象的counts层 |
| chapter14_umap_coordinates.csv | cell ID、UMAP1/2、resolution0.8标签 | 2026-07-10已保存结果；坐标无组织距离单位 |
| chapter14_cluster_counts.csv | resolution、cluster、n_cells | 同80细胞四档resolution的既有结果 |
| chapter14_marker_table.csv | Seurat marker检验字段、cluster与gene | 同数据聚类后探索性结果 |
| chapter14_highly_variable_features.csv | rank、gene | 既有Seurat vst选择200特征 |
| constructed_qc.csv | cell/sample/donor、总计数、检测基因数、pct_mt百分比 | 独立教学构造，6细胞；不属于pbmc_small或骨髓 |
