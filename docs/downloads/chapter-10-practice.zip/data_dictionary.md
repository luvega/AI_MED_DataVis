# 数据字典

| 文件 | 含义 |
| --- | --- |
| 第10章教学模拟分析表.csv | 160人，每人一行；sample_id、patient_id、group、ALT、AST、age、sex、dose、response、time_to_event、event |
| 第10章数据划分记录.csv | sample_id到train/test，120/40 |
| 第10章交叉验证折记录.csv | 120个训练sample_id到fold1—5，每折24人 |
| 第10章重复测量泄漏演示表.csv | 160人的两次近似测量，320行；visit_id、patient_id、visit、四个特征及response |
| 第10章重复测量划分记录.csv | visit_id对应按行随机及患者成组两种划分 |

ALT/AST采用教学U/L，age教学岁，dose与time_to_event均为教学单位。response=1为正类；event=1为事件、0为右删失。原模拟规则固定seed=20260710。所有标签均为构造内容。
