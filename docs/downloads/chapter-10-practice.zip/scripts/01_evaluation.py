from __future__ import annotations

import json
import platform
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
import statsmodels
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    roc_auc_score,
)
from sklearn.model_selection import (
    GridSearchCV,
    GroupShuffleSplit,
    PredefinedSplit,
    StratifiedKFold,
    cross_val_score,
    train_test_split,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier, export_text
from statsmodels.duration.survfunc import SurvfuncRight, survdiff


SEED = 20260710
N = 160
FEATURES = ["ALT", "AST", "age", "dose"]
ROOT = Path(__file__).resolve().parents[1]
OUTDIR = ROOT / "outputs"
OUTDIR.mkdir(exist_ok=True)
RAW = ROOT / "data" / "raw"
DATA_PATH = RAW / "第10章教学模拟分析表.csv"
SPLIT_PATH = RAW / "第10章数据划分记录.csv"
FOLD_PATH = RAW / "第10章交叉验证折记录.csv"
REPEATED_PATH = RAW / "第10章重复测量泄漏演示表.csv"
REPEATED_SPLIT_PATH = RAW / "第10章重复测量划分记录.csv"
TREE_RULES_PATH = OUTDIR / "第10章浅树规则.txt"
RESULT_PATH = OUTDIR / "第10章案例运行结果.json"


def generate_teaching_data() -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    group = np.array(["control"] * (N // 2) + ["treatment"] * (N // 2))
    rng.shuffle(group)
    sex = rng.choice(["female", "male"], size=N)
    age = np.clip(np.rint(rng.normal(45, 12, size=N)), 18, 75).astype(int)
    dose = np.clip(rng.normal(50, 11, size=N), 20, 80)

    # These relations create a reproducible teaching example, not a medical model.
    alt = rng.normal(42 - 1.5 * (group == "treatment"), 9, size=N)
    ast = 0.55 * alt + rng.normal(13, 4.5, size=N)
    linear_score = (
        -4.2
        + 0.045 * alt
        + 0.025 * age
        + 0.012 * dose
        + 0.25 * (group == "treatment")
        - 0.10 * (sex == "male")
    )
    response_prob = 1 / (1 + np.exp(-linear_score))
    response = rng.binomial(1, response_prob)

    event_time = rng.exponential(scale=24, size=N)
    censor_time = rng.uniform(8, 40, size=N)
    time_to_event = np.minimum(event_time, censor_time) + 0.5
    event = (event_time <= censor_time).astype(int)

    return pd.DataFrame(
        {
            "sample_id": [f"S{i:03d}" for i in range(1, N + 1)],
            "patient_id": [f"P{i:03d}" for i in range(1, N + 1)],
            "group": group,
            "ALT": np.round(alt, 1),
            "AST": np.round(ast, 1),
            "age": age,
            "sex": sex,
            "dose": np.round(dose, 1),
            "response": response,
            "time_to_event": np.round(time_to_event, 1),
            "event": event,
        }
    )


def validate_data(data: pd.DataFrame) -> None:
    expected = [
        "sample_id",
        "patient_id",
        "group",
        "ALT",
        "AST",
        "age",
        "sex",
        "dose",
        "response",
        "time_to_event",
        "event",
    ]
    assert data.columns.tolist() == expected
    assert data.shape == (N, len(expected))
    assert data["sample_id"].is_unique
    assert data["patient_id"].is_unique
    assert data.isna().sum().sum() == 0
    assert set(data["response"].unique()) == {0, 1}
    assert set(data["event"].unique()) == {0, 1}


def make_split(data: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    train_ids, test_ids = train_test_split(
        data["sample_id"],
        test_size=0.25,
        random_state=SEED,
        stratify=data["response"],
    )
    split = pd.DataFrame(
        {
            "sample_id": data["sample_id"],
            "set": np.where(data["sample_id"].isin(test_ids), "test", "train"),
        }
    )
    train = data.merge(split.query("set == 'train'"), on="sample_id", how="inner")
    test = data.merge(split.query("set == 'test'"), on="sample_id", how="inner")
    assert train.shape[0] == 120
    assert test.shape[0] == 40
    assert set(train["sample_id"]).isdisjoint(test["sample_id"])
    return train, test, split


def make_fold_manifest(train: pd.DataFrame) -> pd.DataFrame:
    manifest = pd.DataFrame({"sample_id": train["sample_id"], "fold": 0})
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
    for fold, (_, valid_idx) in enumerate(cv.split(train[FEATURES], train["response"]), start=1):
        manifest.loc[valid_idx, "fold"] = fold
    assert set(manifest["fold"]) == {1, 2, 3, 4, 5}
    return manifest


def generate_repeated_measure_example(
    data: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(SEED + 30)
    rows: list[dict] = []
    for row in data.to_dict(orient="records"):
        for visit in (1, 2):
            rows.append(
                {
                    "visit_id": f"{row['patient_id']}_V{visit}",
                    "patient_id": row["patient_id"],
                    "visit": visit,
                    "ALT": round(float(row["ALT"]) + rng.normal(0, 0.35), 2),
                    "AST": round(float(row["AST"]) + rng.normal(0, 0.35), 2),
                    "age": row["age"],
                    "dose": row["dose"],
                    "response": row["response"],
                }
            )
    repeated = pd.DataFrame(rows)

    row_train_ids, row_test_ids = train_test_split(
        repeated["visit_id"],
        test_size=0.25,
        random_state=SEED,
        stratify=repeated["response"],
    )
    group_splitter = GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=SEED)
    group_train_idx, group_test_idx = next(
        group_splitter.split(repeated[FEATURES], repeated["response"], repeated["patient_id"])
    )
    group_test_ids = set(repeated.iloc[group_test_idx]["visit_id"])
    manifest = pd.DataFrame(
        {
            "visit_id": repeated["visit_id"],
            "row_random_set": np.where(repeated["visit_id"].isin(row_test_ids), "test", "train"),
            "patient_group_set": np.where(repeated["visit_id"].isin(group_test_ids), "test", "train"),
        }
    )
    assert len(row_train_ids) == 240
    assert len(group_train_idx) == 240
    return repeated, manifest


def logistic_pipeline() -> Pipeline:
    return Pipeline(
        [
            ("scale", StandardScaler()),
            ("model", LogisticRegression(C=1e6, l1_ratio=0.0, solver="lbfgs", max_iter=3000)),
        ]
    )


def lasso_pipeline(c_value: float = 1.0) -> Pipeline:
    return Pipeline(
        [
            ("scale", StandardScaler()),
            (
                "model",
                LogisticRegression(
                    C=c_value,
                    l1_ratio=1.0,
                    solver="liblinear",
                    max_iter=3000,
                    random_state=SEED,
                ),
            ),
        ]
    )


def classification_metrics(y_true: pd.Series | np.ndarray, probabilities: np.ndarray) -> dict:
    y_array = np.asarray(y_true)
    predictions = (probabilities >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_array, predictions, labels=[0, 1]).ravel()
    return {
        "auc": float(roc_auc_score(y_array, probabilities)),
        "pr_auc": float(average_precision_score(y_array, probabilities)),
        "brier_score": float(brier_score_loss(y_array, probabilities)),
        "accuracy": float(accuracy_score(y_array, predictions)),
        "sensitivity": float(tp / (tp + fn)),
        "specificity": float(tn / (tn + fp)),
        "positive_predictive_value": float(tp / (tp + fp)) if tp + fp else None,
        "negative_predictive_value": float(tn / (tn + fn)) if tn + fn else None,
        "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
    }


def repeated_holdout_auc(data: pd.DataFrame) -> list[float]:
    values: list[float] = []
    for seed in range(101, 121):
        train, test = train_test_split(
            data,
            test_size=0.25,
            random_state=seed,
            stratify=data["response"],
        )
        model = logistic_pipeline().fit(train[FEATURES], train["response"])
        probability = model.predict_proba(test[FEATURES])[:, 1]
        values.append(float(roc_auc_score(test["response"], probability)))
    return values


def bootstrap_auc(y_true: np.ndarray, probabilities: np.ndarray) -> np.ndarray:
    rng = np.random.default_rng(SEED + 1)
    values = []
    for _ in range(2000):
        idx = rng.integers(0, len(y_true), len(y_true))
        if np.unique(y_true[idx]).size == 2:
            values.append(roc_auc_score(y_true[idx], probabilities[idx]))
    return np.asarray(values, dtype=float)


def survival_probability_at(fit: SurvfuncRight, time_point: float) -> float:
    eligible = np.flatnonzero(fit.surv_times <= time_point)
    if eligible.size == 0:
        return 1.0
    return float(fit.surv_prob[eligible[-1]])


def risk_count_at(time: pd.Series, time_point: float) -> int:
    return int((time >= time_point).sum())


def evaluate_repeated_measure_leakage(
    repeated: pd.DataFrame, manifest: pd.DataFrame
) -> dict:
    joined = repeated.merge(manifest, on="visit_id", validate="one_to_one")
    output: dict[str, dict] = {}
    for label, split_column in (
        ("row_random", "row_random_set"),
        ("patient_group", "patient_group_set"),
    ):
        train = joined[joined[split_column] == "train"]
        test = joined[joined[split_column] == "test"]
        model = RandomForestClassifier(
            n_estimators=500,
            min_samples_leaf=1,
            class_weight="balanced",
            random_state=SEED,
            n_jobs=-1,
        )
        model.fit(train[FEATURES], train["response"])
        probability = model.predict_proba(test[FEATURES])[:, 1]
        overlap = len(set(train["patient_id"]) & set(test["patient_id"]))
        output[label] = {
            "train_n": int(len(train)),
            "test_n": int(len(test)),
            "patient_overlap": int(overlap),
            "test_auc": float(roc_auc_score(test["response"], probability)),
        }
    return output


def run_analysis(
    data: pd.DataFrame,
    train: pd.DataFrame,
    test: pd.DataFrame,
    fold_manifest: pd.DataFrame,
    repeated: pd.DataFrame,
    repeated_manifest: pd.DataFrame,
) -> dict:
    holdout = np.asarray(repeated_holdout_auc(data))
    fold_ids = train["sample_id"].map(fold_manifest.set_index("sample_id")["fold"]).to_numpy()
    assert not np.isnan(fold_ids).any()
    predefined = PredefinedSplit(test_fold=fold_ids.astype(int) - 1)

    base_model = logistic_pipeline()
    cv_auc = cross_val_score(
        base_model,
        train[FEATURES],
        train["response"],
        cv=predefined,
        scoring="roc_auc",
    )
    base_model.fit(train[FEATURES], train["response"])
    test_probability = base_model.predict_proba(test[FEATURES])[:, 1]
    test_metrics = classification_metrics(test["response"], test_probability)
    boot = bootstrap_auc(test["response"].to_numpy(), test_probability)

    lasso_search = GridSearchCV(
        estimator=lasso_pipeline(),
        param_grid={"model__C": np.logspace(-2, 2, 12)},
        cv=predefined,
        scoring="roc_auc",
        refit=True,
        return_train_score=True,
        n_jobs=-1,
    )
    lasso_search.fit(train[FEATURES], train["response"])
    lasso_coefficient = lasso_search.best_estimator_.named_steps["model"].coef_[0]
    lasso_probability = lasso_search.predict_proba(test[FEATURES])[:, 1]
    best_c = float(lasso_search.best_params_["model__C"])
    selection_count = dict.fromkeys(FEATURES, 0)
    for fold in range(1, 6):
        subset = train.loc[fold_ids != fold]
        fold_model = lasso_pipeline(best_c).fit(subset[FEATURES], subset["response"])
        for feature, coefficient in zip(FEATURES, fold_model.named_steps["model"].coef_[0]):
            if not np.isclose(coefficient, 0):
                selection_count[feature] += 1

    tree = DecisionTreeClassifier(max_depth=3, min_samples_leaf=10, random_state=SEED)
    tree.fit(train[FEATURES], train["response"])
    tree_probability = tree.predict_proba(test[FEATURES])[:, 1]
    tree_rules = export_text(tree, feature_names=FEATURES)
    TREE_RULES_PATH.write_text(tree_rules, encoding="utf-8")

    forest = RandomForestClassifier(
        n_estimators=500,
        max_depth=4,
        min_samples_leaf=5,
        class_weight="balanced",
        oob_score=True,
        random_state=SEED,
        n_jobs=-1,
    )
    forest.fit(train[FEATURES], train["response"])
    forest_probability = forest.predict_proba(test[FEATURES])[:, 1]
    permutation = permutation_importance(
        forest,
        test[FEATURES],
        test["response"],
        scoring="roc_auc",
        n_repeats=30,
        random_state=SEED,
        n_jobs=-1,
    )

    overall_km = SurvfuncRight(data["time_to_event"], data["event"], title="all")
    group_km = {}
    for group_name, part in data.groupby("group", sort=True):
        fit = SurvfuncRight(part["time_to_event"], part["event"], title=group_name)
        group_km[group_name] = {
            "n": int(len(part)),
            "events": int(part["event"].sum()),
            "risk_at_12": risk_count_at(part["time_to_event"], 12),
            "survival_at_12": survival_probability_at(fit, 12),
        }
    logrank_stat, logrank_p = survdiff(
        data["time_to_event"].to_numpy(),
        data["event"].to_numpy(),
        data["group"].to_numpy(),
    )

    return {
        "metadata": {
            "seed": SEED,
            "python": platform.python_version(),
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "scikit_learn": sklearn.__version__,
            "statsmodels": statsmodels.__version__,
            "teaching_only": True,
        },
        "data_summary": {
            "rows": int(len(data)),
            "columns": int(data.shape[1]),
            "response_1": int(data["response"].sum()),
            "event_1": int(data["event"].sum()),
            "group_counts": {
                key: int(value)
                for key, value in data["group"].value_counts().sort_index().items()
            },
        },
        "split": {
            "train_n": int(len(train)),
            "test_n": int(len(test)),
            "train_positive_rate": float(train["response"].mean()),
            "test_positive_rate": float(test["response"].mean()),
            "shared_fold_counts": {
                str(key): int(value)
                for key, value in fold_manifest["fold"].value_counts().sort_index().items()
            },
        },
        "repeated_measure_leakage": evaluate_repeated_measure_leakage(
            repeated, repeated_manifest
        ),
        "repeated_holdout": {
            "n_splits": int(len(holdout)),
            "auc_values": holdout.tolist(),
            "mean_auc": float(holdout.mean()),
            "sd_auc": float(holdout.std(ddof=1)),
            "min_auc": float(holdout.min()),
            "max_auc": float(holdout.max()),
        },
        "cross_validation": {
            "fold_auc": cv_auc.tolist(),
            "mean_auc": float(cv_auc.mean()),
            "sd_auc": float(cv_auc.std(ddof=1)),
            "fold_source": FOLD_PATH.name,
        },
        "logistic_test": test_metrics,
        "bootstrap": {
            "valid_resamples": int(len(boot)),
            "auc_values": boot.tolist(),
            "auc_ci_percentile_95": [float(value) for value in np.quantile(boot, [0.025, 0.975])],
            "auc_median": float(np.median(boot)),
        },
        "lasso": {
            "best_C": best_c,
            "coefficients_standardized": {
                feature: float(coefficient)
                for feature, coefficient in zip(FEATURES, lasso_coefficient)
            },
            "selected_features": [
                feature
                for feature, coefficient in zip(FEATURES, lasso_coefficient)
                if not np.isclose(coefficient, 0)
            ],
            "selection_frequency_across_five_training_subsets": {
                feature: count / 5 for feature, count in selection_count.items()
            },
            "test_auc": float(roc_auc_score(test["response"], lasso_probability)),
        },
        "shallow_tree": {
            "max_depth": 3,
            "min_samples_leaf": 10,
            "test": classification_metrics(test["response"], tree_probability),
            "rules_file": TREE_RULES_PATH.name,
        },
        "random_forest": {
            "test": classification_metrics(test["response"], forest_probability),
            "oob_accuracy": float(forest.oob_score_),
            "impurity_importance": {
                feature: float(value) for feature, value in zip(FEATURES, forest.feature_importances_)
            },
            "permutation_importance_auc_mean": {
                feature: float(value)
                for feature, value in zip(FEATURES, permutation.importances_mean)
            },
            "permutation_importance_auc_sd": {
                feature: float(value)
                for feature, value in zip(FEATURES, permutation.importances_std)
            },
        },
        "survival": {
            "overall_survival_at_12": survival_probability_at(overall_km, 12),
            "groups": group_km,
            "logrank_chi_square": float(logrank_stat),
            "logrank_p": float(logrank_p),
        },
    }


def main() -> None:
    data = pd.read_csv(DATA_PATH, encoding="utf-8-sig")
    validate_data(data)
    split = pd.read_csv(SPLIT_PATH, encoding="utf-8-sig")
    joined = data.merge(split, on="sample_id", validate="one_to_one")
    train = joined.loc[joined["set"] == "train"].reset_index(drop=True)
    test = joined.loc[joined["set"] == "test"].reset_index(drop=True)
    assert set(train["patient_id"]).isdisjoint(test["patient_id"])
    fold_manifest = pd.read_csv(FOLD_PATH, encoding="utf-8-sig")
    repeated = pd.read_csv(REPEATED_PATH, encoding="utf-8-sig")
    repeated_manifest = pd.read_csv(REPEATED_SPLIT_PATH, encoding="utf-8-sig")

    results = run_analysis(
        data,
        train,
        test,
        fold_manifest,
        repeated,
        repeated_manifest,
    )
    RESULT_PATH.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")

    print("DATA_CHECK=PASS")
    print("PYTHON_ANALYSIS=PASS")
    print(f"DATA_ROWS={len(data)} TRAIN_N={len(train)} TEST_N={len(test)}")
    print(f"CV_AUC_MEAN={results['cross_validation']['mean_auc']:.3f}")
    print(f"TEST_AUC={results['logistic_test']['auc']:.3f}")
    print(f"LASSO_TEST_AUC={results['lasso']['test_auc']:.3f}")


if __name__ == "__main__":
    main()
