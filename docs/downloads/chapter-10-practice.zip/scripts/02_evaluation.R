args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
script_path <- normalizePath(sub("^--file=", "", file_arg), winslash = "/")
root <- normalizePath(file.path(dirname(script_path), ".."), winslash = "/")
outdir <- file.path(root, "outputs")
rawdir <- file.path(root, "data", "raw")
dir.create(outdir, showWarnings = FALSE)
artifact_dir <- file.path(outdir, "case_artifacts")
dir.create(artifact_dir, recursive = TRUE, showWarnings = FALSE)

data_path <- file.path(rawdir, "第10章教学模拟分析表.csv")
split_path <- file.path(rawdir, "第10章数据划分记录.csv")
fold_path <- file.path(rawdir, "第10章交叉验证折记录.csv")
repeated_path <- file.path(rawdir, "第10章重复测量泄漏演示表.csv")
repeated_split_path <- file.path(rawdir, "第10章重复测量划分记录.csv")
result_path <- file.path(outdir, "第10章案例运行结果-R.txt")
lasso_figure_path <- file.path(artifact_dir, "fig10-3-r-glmnet-coefficient-path.png")

required_packages <- c("pROC", "randomForest", "survival", "glmnet")
available <- vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
if (!all(available)) {
  stop("Missing R packages: ", paste(names(available)[!available], collapse = ", "))
}

read_utf8_csv <- function(path) {
  read.csv(path, fileEncoding = "UTF-8-BOM", check.names = FALSE)
}

data <- read_utf8_csv(data_path)
split <- read_utf8_csv(split_path)
fold_manifest <- read_utf8_csv(fold_path)
repeated <- read_utf8_csv(repeated_path)
repeated_split <- read_utf8_csv(repeated_split_path)

data$set <- split$set[match(data$sample_id, split$sample_id)]
repeated$row_random_set <- repeated_split$row_random_set[
  match(repeated$visit_id, repeated_split$visit_id)
]
repeated$patient_group_set <- repeated_split$patient_group_set[
  match(repeated$visit_id, repeated_split$visit_id)
]

expected <- c(
  "sample_id", "patient_id", "group", "ALT", "AST", "age", "sex",
  "dose", "response", "time_to_event", "event", "set"
)
stopifnot(nrow(data) == 160)
stopifnot(all(expected %in% names(data)))
stopifnot(!anyDuplicated(data$sample_id))
stopifnot(!anyNA(data))
stopifnot(identical(sort(unique(data$response)), c(0L, 1L)))
stopifnot(identical(sort(unique(data$event)), c(0L, 1L)))
stopifnot(nrow(repeated) == 320)
stopifnot(!anyNA(repeated))

features <- c("ALT", "AST", "age", "dose")
train <- data[data$set == "train", ]
test <- data[data$set == "test", ]
fold_id <- fold_manifest$fold[match(train$sample_id, fold_manifest$sample_id)]
stopifnot(nrow(train) == 120, nrow(test) == 40)
stopifnot(length(intersect(train$sample_id, test$sample_id)) == 0)
stopifnot(!anyNA(fold_id), identical(sort(unique(fold_id)), 1:5))
stopifnot(all(table(fold_id) == 24))

auc_value <- function(y, p) {
  as.numeric(pROC::auc(y, p, levels = c(0, 1), direction = "<", quiet = TRUE))
}

standardize_train_test <- function(train_data, test_data, feature_names) {
  means <- vapply(train_data[feature_names], mean, numeric(1))
  sds <- vapply(train_data[feature_names], sd, numeric(1))
  if (any(sds == 0)) stop("A training-fold feature has zero variance")

  train_x <- sweep(as.matrix(train_data[feature_names]), 2, means, "-")
  train_x <- sweep(train_x, 2, sds, "/")
  test_x <- sweep(as.matrix(test_data[feature_names]), 2, means, "-")
  test_x <- sweep(test_x, 2, sds, "/")
  list(
    train = data.frame(response = train_data$response, train_x, check.names = FALSE),
    test = data.frame(test_x, check.names = FALSE)
  )
}

fit_predict_glm <- function(train_data, test_data) {
  scaled <- standardize_train_test(train_data, test_data, features)
  fit <- glm(response ~ ., data = scaled$train, family = binomial())
  probability <- as.numeric(predict(fit, newdata = scaled$test, type = "response"))
  list(fit = fit, probability = probability)
}

classification_metrics <- function(y, p, threshold = 0.5) {
  pred <- ifelse(p >= threshold, 1L, 0L)
  tp <- sum(pred == 1 & y == 1)
  tn <- sum(pred == 0 & y == 0)
  fp <- sum(pred == 1 & y == 0)
  fn <- sum(pred == 0 & y == 1)
  c(
    auc = auc_value(y, p),
    brier_score = mean((p - y)^2),
    accuracy = mean(pred == y),
    sensitivity = tp / (tp + fn),
    specificity = tn / (tn + fp),
    positive_predictive_value = if ((tp + fp) > 0) tp / (tp + fp) else NA_real_,
    negative_predictive_value = if ((tn + fn) > 0) tn / (tn + fn) else NA_real_,
    tn = tn, fp = fp, fn = fn, tp = tp
  )
}

cv_auc <- vapply(seq_len(5), function(fold) {
  fold_train <- train[fold_id != fold, ]
  fold_valid <- train[fold_id == fold, ]
  result <- fit_predict_glm(fold_train, fold_valid)
  auc_value(fold_valid$response, result$probability)
}, numeric(1))

glm_result <- fit_predict_glm(train, test)
glm_metrics <- classification_metrics(test$response, glm_result$probability)

set.seed(20260711)
boot_auc <- replicate(2000, {
  idx <- sample(seq_len(nrow(test)), replace = TRUE)
  if (length(unique(test$response[idx])) < 2) return(NA_real_)
  auc_value(test$response[idx], glm_result$probability[idx])
})
boot_auc <- boot_auc[!is.na(boot_auc)]
boot_ci <- unname(quantile(boot_auc, c(0.025, 0.975)))

x_train <- as.matrix(train[features])
x_test <- as.matrix(test[features])
y_train <- train$response
set.seed(20260710)
lasso_cv <- glmnet::cv.glmnet(
  x = x_train,
  y = y_train,
  family = "binomial",
  alpha = 1,
  foldid = fold_id,
  type.measure = "auc",
  standardize = TRUE,
  keep = TRUE
)
lasso_prob_min <- as.numeric(predict(lasso_cv, newx = x_test, s = "lambda.min", type = "response"))
lasso_prob_1se <- as.numeric(predict(lasso_cv, newx = x_test, s = "lambda.1se", type = "response"))
lasso_metrics_min <- classification_metrics(test$response, lasso_prob_min)
lasso_metrics_1se <- classification_metrics(test$response, lasso_prob_1se)

coefficient_vector <- function(fit, s_value) {
  matrix_value <- as.matrix(coef(fit, s = s_value))
  stats::setNames(as.numeric(matrix_value[, 1]), rownames(matrix_value))
}

lasso_coef_min <- coefficient_vector(lasso_cv, "lambda.min")
lasso_coef_1se <- coefficient_vector(lasso_cv, "lambda.1se")
selected_features <- function(coef_value) {
  names(coef_value)[names(coef_value) != "(Intercept)" & abs(coef_value) > 1e-10]
}
lasso_selected_min <- selected_features(lasso_coef_min)
lasso_selected_1se <- selected_features(lasso_coef_1se)

selection_count <- stats::setNames(numeric(length(features)), features)
for (outer_fold in seq_len(5)) {
  idx <- fold_id != outer_fold
  inner_fold <- as.integer(factor(fold_id[idx]))
  set.seed(20260710 + outer_fold)
  outer_fit <- glmnet::cv.glmnet(
    x = x_train[idx, , drop = FALSE],
    y = y_train[idx],
    family = "binomial",
    alpha = 1,
    foldid = inner_fold,
    type.measure = "auc",
    standardize = TRUE
  )
  selected <- selected_features(coefficient_vector(outer_fit, "lambda.1se"))
  selection_count[selected] <- selection_count[selected] + 1
}
selection_frequency <- selection_count / 5

grDevices::png(lasso_figure_path, width = 1800, height = 1200, res = 180)
graphics::par(mar = c(5, 5, 4, 2) + 0.1)
path_fit <- lasso_cv$glmnet.fit
path_x <- -log(path_fit$lambda)
path_beta <- t(as.matrix(path_fit$beta))
path_colors <- c("#0072B2", "#D55E00", "#009E73", "#CC79A7")
graphics::matplot(
  path_x,
  path_beta,
  type = "l",
  lty = 1,
  lwd = 2,
  col = path_colors,
  xlab = "-log(lambda)",
  ylab = "Coefficient",
  main = "Lasso coefficient paths on the shared training set"
)
graphics::abline(v = -log(lasso_cv$lambda.min), col = "#333333", lty = 2, lwd = 2)
graphics::abline(v = -log(lasso_cv$lambda.1se), col = "#777777", lty = 3, lwd = 2)
graphics::legend(
  "topleft",
  legend = features,
  col = path_colors,
  lty = 1,
  lwd = 2,
  bty = "n"
)
graphics::legend(
  "topright",
  legend = c("lambda.min", "lambda.1se"),
  col = c("#333333", "#777777"),
  lty = c(2, 3),
  lwd = 2,
  bty = "n"
)
grDevices::dev.off()

set.seed(20260710)
rf_fit <- randomForest::randomForest(
  x = train[features],
  y = factor(train$response, levels = c(0, 1)),
  ntree = 500,
  nodesize = 5,
  importance = TRUE,
  keep.forest = TRUE
)
rf_prob <- predict(rf_fit, newdata = test[features], type = "prob")[, "1"]
rf_metrics <- classification_metrics(test$response, rf_prob)
rf_gini <- randomForest::importance(rf_fit, type = 2, scale = FALSE)[, 1]
rf_permutation <- randomForest::importance(rf_fit, type = 1, scale = FALSE)[, 1]
rf_oob_accuracy <- 1 - tail(rf_fit$err.rate[, "OOB"], 1)

evaluate_leakage_split <- function(split_column) {
  leak_train <- repeated[repeated[[split_column]] == "train", ]
  leak_test <- repeated[repeated[[split_column]] == "test", ]
  set.seed(20260710)
  fit <- randomForest::randomForest(
    x = leak_train[features],
    y = factor(leak_train$response, levels = c(0, 1)),
    ntree = 500,
    nodesize = 1
  )
  probability <- predict(fit, newdata = leak_test[features], type = "prob")[, "1"]
  list(
    auc = auc_value(leak_test$response, probability),
    overlap = length(intersect(leak_train$patient_id, leak_test$patient_id))
  )
}
leakage_row <- evaluate_leakage_split("row_random_set")
leakage_group <- evaluate_leakage_split("patient_group_set")

surv_object <- survival::Surv(data$time_to_event, data$event)
km_fit <- survival::survfit(surv_object ~ group, data = data)
km_12 <- summary(km_fit, times = 12, extend = TRUE)
logrank <- survival::survdiff(surv_object ~ group, data = data)
logrank_p <- 1 - pchisq(logrank$chisq, df = length(logrank$n) - 1)

cox_fit <- survival::coxph(
  survival::Surv(time_to_event, event) ~ age + ALT + AST + group,
  data = data,
  x = TRUE
)
cox_summary <- summary(cox_fit)
ph_test <- survival::cox.zph(cox_fit)

fmt <- function(x, digits = 6) formatC(x, digits = digits, format = "f")
format_named <- function(values, digits = 6) {
  paste(names(values), fmt(values, digits), sep = ":", collapse = ",")
}

lines <- c(
  "R_ANALYSIS=PASS",
  paste0("R_VERSION=", R.version.string),
  paste0("pROC_VERSION=", as.character(utils::packageVersion("pROC"))),
  paste0("randomForest_VERSION=", as.character(utils::packageVersion("randomForest"))),
  paste0("survival_VERSION=", as.character(utils::packageVersion("survival"))),
  paste0("glmnet_AVAILABLE=", requireNamespace("glmnet", quietly = TRUE)),
  paste0("glmnet_VERSION=", as.character(utils::packageVersion("glmnet"))),
  paste0("DATA_ROWS=", nrow(data)),
  paste0("TRAIN_N=", nrow(train)),
  paste0("TEST_N=", nrow(test)),
  paste0("SHARED_FOLD_COUNTS=", paste(names(table(fold_id)), table(fold_id), sep = ":", collapse = ",")),
  paste0("TRAIN_POSITIVE_RATE=", fmt(mean(train$response), 4)),
  paste0("TEST_POSITIVE_RATE=", fmt(mean(test$response), 4)),
  paste0("CV_FOLD_AUC=", paste(fmt(cv_auc, 4), collapse = ",")),
  paste0("CV_MEAN_AUC=", fmt(mean(cv_auc), 4)),
  paste0("CV_SD_AUC=", fmt(sd(cv_auc), 4)),
  paste0("GLM_TEST_AUC=", fmt(glm_metrics["auc"], 4)),
  paste0("GLM_TEST_BRIER=", fmt(glm_metrics["brier_score"], 4)),
  paste0("GLM_TEST_ACCURACY=", fmt(glm_metrics["accuracy"], 4)),
  paste0("GLM_TEST_SENSITIVITY=", fmt(glm_metrics["sensitivity"], 4)),
  paste0("GLM_TEST_SPECIFICITY=", fmt(glm_metrics["specificity"], 4)),
  paste0("GLM_TEST_PPV=", fmt(glm_metrics["positive_predictive_value"], 4)),
  paste0("GLM_TEST_NPV=", fmt(glm_metrics["negative_predictive_value"], 4)),
  paste0(
    "GLM_CONFUSION=tn:", glm_metrics["tn"], ",fp:", glm_metrics["fp"],
    ",fn:", glm_metrics["fn"], ",tp:", glm_metrics["tp"]
  ),
  paste0("BOOTSTRAP_VALID=", length(boot_auc)),
  paste0("BOOTSTRAP_AUC_CI95=", fmt(boot_ci[1], 4), ",", fmt(boot_ci[2], 4)),
  paste0("LASSO_LAMBDA_MIN=", fmt(lasso_cv$lambda.min, 8)),
  paste0("LASSO_LAMBDA_1SE=", fmt(lasso_cv$lambda.1se, 8)),
  paste0("LASSO_MIN_SELECTED=", paste(lasso_selected_min, collapse = ",")),
  paste0("LASSO_1SE_SELECTED=", paste(lasso_selected_1se, collapse = ",")),
  paste0("LASSO_MIN_COEFFICIENTS=", format_named(lasso_coef_min[names(lasso_coef_min) != "(Intercept)"], 6)),
  paste0("LASSO_1SE_COEFFICIENTS=", format_named(lasso_coef_1se[names(lasso_coef_1se) != "(Intercept)"], 6)),
  paste0("LASSO_SELECTION_FREQUENCY=", format_named(selection_frequency, 2)),
  paste0("LASSO_MIN_TEST_AUC=", fmt(lasso_metrics_min["auc"], 4)),
  paste0("LASSO_1SE_TEST_AUC=", fmt(lasso_metrics_1se["auc"], 4)),
  paste0("LASSO_FIGURE=", basename(lasso_figure_path)),
  paste0("RF_TEST_AUC=", fmt(rf_metrics["auc"], 4)),
  paste0("RF_TEST_ACCURACY=", fmt(rf_metrics["accuracy"], 4)),
  paste0("RF_OOB_ACCURACY=", fmt(rf_oob_accuracy, 4)),
  paste0("RF_GINI_IMPORTANCE=", format_named(rf_gini, 4)),
  paste0("RF_OOB_PERMUTATION_IMPORTANCE=", format_named(rf_permutation, 4)),
  paste0("LEAKAGE_ROW_SPLIT_AUC=", fmt(leakage_row$auc, 4)),
  paste0("LEAKAGE_ROW_PATIENT_OVERLAP=", leakage_row$overlap),
  paste0("LEAKAGE_GROUP_SPLIT_AUC=", fmt(leakage_group$auc, 4)),
  paste0("LEAKAGE_GROUP_PATIENT_OVERLAP=", leakage_group$overlap),
  paste0(
    "KM_AT_12=",
    paste(km_12$strata, "n_risk", km_12$n.risk, "survival", fmt(km_12$surv, 4), collapse = ";")
  ),
  paste0("LOGRANK_CHISQ=", fmt(logrank$chisq, 4)),
  paste0("LOGRANK_P=", fmt(logrank_p, 4)),
  "COX_FIELDS=variable,coef,HR,CI_lower,CI_upper,p",
  paste0(
    "COX_RESULTS=",
    paste(
      rownames(cox_summary$coefficients),
      fmt(cox_summary$coefficients[, "coef"], 4),
      fmt(cox_summary$coefficients[, "exp(coef)"], 4),
      fmt(cox_summary$conf.int[, "lower .95"], 4),
      fmt(cox_summary$conf.int[, "upper .95"], 4),
      fmt(cox_summary$coefficients[, "Pr(>|z|)"], 4),
      sep = ":",
      collapse = ";"
    )
  ),
  paste0("COX_PH_GLOBAL_P=", fmt(ph_test$table["GLOBAL", "p"], 4)),
  "INTERPRETATION_BOUNDARY=teaching_simulation_only"
)

writeLines(lines, result_path, useBytes = TRUE)
cat("DATA_CHECK=PASS\n")
cat("R_ANALYSIS=PASS\n")
cat("glmnet_AVAILABLE=TRUE\n")
cat("CV_AUC_MEAN=", fmt(mean(cv_auc), 3), "\n", sep = "")
cat("TEST_AUC=", fmt(glm_metrics["auc"], 3), "\n", sep = "")
cat("LASSO_MIN_TEST_AUC=", fmt(lasso_metrics_min["auc"], 3), "\n", sep = "")
