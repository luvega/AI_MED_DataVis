# 第10章 模型评估、特征选择与可解释性练习包

本包对应10.1—10.6。160行构造表、共享训练/测试与五折记录用于评估；320行重复测量表用于定位患者跨集合问题。

解压后进入本目录，在终端按顺序运行下面的演示。Python需要pandas、numpy、scipy、matplotlib、scikit-learn、statsmodels；第11章另需seaborn。R脚本所需包见脚本开头。包内数据均可离线读取；安装软件和依赖需要在上课前完成。

```text
python scripts/01_evaluation.py
Rscript scripts/02_evaluation.R
```

脚本按自身位置查找输入，可从其他目录调用。所有新结果写入outputs；data/raw保留原输入。先预测关键结果，再运行核对，最后按exercises.md修改一个条件。文件名出现中文时保留UTF-8；CSV输入编码见bundle.json。独立练习没有附完整答案。

正文中的短代码用于逐步讲解，scripts中的文件给出完整演示。记录数据、参数和实际输出，使用records.md整理自己的运行过程。
