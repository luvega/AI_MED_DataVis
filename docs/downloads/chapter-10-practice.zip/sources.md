# 来源

固定输入及Python/R流程来自outputs/2026-07-16-第10章正文扩写完善。保留原有随机种子、构造值、训练/测试以及共享fold记录。演示读取这些输入；不重写data/raw。

原章节ISLR/ISLP的Auto、Heart、Portfolio、BrainCancer素材继续用于方法讲解，这些素材数值与本包教学模型结果分别标识。Python需numpy、pandas、scikit-learn、statsmodels；R完整对照另需glmnet、randomForest、survival。环境与实际软件结果需记录，随机模型存在实现差异。
