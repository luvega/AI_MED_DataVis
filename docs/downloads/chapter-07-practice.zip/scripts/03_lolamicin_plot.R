# 基础R由同一36行CSV重新计算12组n、mean、SD、SEM。
args <- commandArgs(trailingOnly=FALSE)
script <- sub("^--file=", "", args[grepl("^--file=", args)])
root <- normalizePath(file.path(dirname(script), ".."), winslash="/")
out <- file.path(root, "outputs")
dir.create(out, showWarnings=FALSE)
df <- read.csv(file.path(root,"data/raw/lolamicin_ecoli_timekill.csv"),stringsAsFactors=FALSE)
parts <- split(df,list(df$treatment,df$time_h),drop=TRUE)
summary <- do.call(rbind,lapply(parts,function(x) data.frame(treatment=x$treatment[1],time_h=x$time_h[1],n=sum(!is.na(x$value)),mean=mean(x$value),sd=sd(x$value))))
rownames(summary) <- NULL
summary$sem <- summary$sd / sqrt(summary$n)
write.csv(summary,file.path(out,"lolamicin_summary_r.csv"),row.names=FALSE)
print(summary)
colors <- c("Untreated control"="#666666","Lolamicin (4X MIC)"="#0072B2","Ciprofloxacin (4X MIC)"="#E69F00")
draw <- function(){
  plot(df$time_h,df$value,log="y",pch=16,col=colors[df$treatment],xlab="Time (h)",ylab="CFU/mL, log10 scale")
  for(treatment in names(colors)){
    means <- summary[summary$treatment==treatment,]
    means <- means[order(means$time_h),]
    lines(means$time_h,means$mean,lty=2,col=colors[treatment])
  }
  legend("topleft",legend=names(colors),col=colors,pch=16,lty=2,cex=0.7)
}
png(file.path(out,"lolamicin_points_means_r.png"),width=1800,height=1200,res=300)
draw()
dev.off()
pdf(file.path(out,"lolamicin_points_means_r.pdf"),width=7,height=4)
draw()
dev.off()
capture.output(sessionInfo(),file=file.path(out,"lolamicin_r_session.txt"))
