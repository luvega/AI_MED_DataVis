"""7.1–7.3：同一成人分析表生成两个分布子图。"""
from pathlib import Path
import json
import platform
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parents[1]
out=root/"outputs"
out.mkdir(exist_ok=True)
df=pd.read_csv(root/"data/raw/nhanes_2017_2018_adult_alt_ast.csv",dtype={"SEQN":"string"})
groups=["Male","Female"]
colors={"Male":"#0072B2","Female":"#E69F00"}
rng=np.random.default_rng(20261002)
fig,axes=plt.subplots(1,2,figsize=(8,3.8))
counts=[]
for ax,field,label,panel in zip(axes,["ALT_U_L","AST_U_L"],["ALT (U/L)","AST (U/L)"],["a","b"]):
    source=df[["SEQN","sex",field]].dropna(subset=[field]).copy()
    if (source[field]<=0).any():
        raise ValueError("Log-scale plot requires positive observed values")
    source.to_csv(out/f"nhanes_{field}_plot_source.csv",index=False)
    values=[source.loc[source["sex"]==group,field].to_numpy() for group in groups]
    ax.boxplot(values,positions=[1,2],widths=0.24,showfliers=False)
    for position,group,y in zip([1,2],groups,values):
        x=position+rng.uniform(-0.16,0.16,len(y))
        ax.scatter(x,y,s=4,alpha=0.18,color=colors[group],zorder=1)
        counts.append({"field":field,"sex":group,"n":len(y)})
    ax.set_xticks([1,2],[f"{g}\nn={len(v)}" for g,v in zip(groups,values)])
    ax.set_yscale("log")
    ax.set_ylabel(label+", log10 scale")
    ax.set_title(panel+". Unweighted records")
fig.tight_layout()
for extension in ["png","svg","pdf"]:
    fig.savefig(out/f"nhanes_alt_ast_python.{extension}",dpi=300,bbox_inches="tight")
plt.close(fig)
pd.DataFrame(counts).to_csv(out/"nhanes_group_counts.csv",index=False)
print("adult records",len(df))
print(pd.DataFrame(counts).to_string(index=False))
(out/"nhanes_plot_session.json").write_text(json.dumps({"python":platform.python_version(),"pandas":pd.__version__,"numpy":np.__version__,"matplotlib":matplotlib.__version__,"seed":20261002},indent=2),encoding="utf-8")
