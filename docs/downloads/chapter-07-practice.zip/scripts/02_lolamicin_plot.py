"""7.4/7.5：由同一36行表计算汇总并绘制全部原始点。"""
from pathlib import Path
import json
import platform
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parents[1]
out=root/"outputs"
out.mkdir(exist_ok=True)
df=pd.read_csv(root/"data/raw/lolamicin_ecoli_timekill.csv")
summary=df.groupby(["treatment","time_h"],sort=False)["value"].agg(n="count",mean="mean",sd="std").reset_index()
summary["sem"]=summary["sd"]/np.sqrt(summary["n"])
summary.to_csv(out/"lolamicin_summary_python.csv",index=False)
df.to_csv(out/"lolamicin_plot_source.csv",index=False)
colors={"Untreated control":"#666666","Lolamicin (4X MIC)":"#0072B2","Ciprofloxacin (4X MIC)":"#E69F00"}
fig,ax=plt.subplots(figsize=(7,4))
for treatment,part in df.groupby("treatment",sort=False):
    ax.scatter(part["time_h"],part["value"],s=26,alpha=0.75,color=colors[treatment])
    means=summary.loc[summary["treatment"]==treatment].sort_values("time_h")
    ax.plot(means["time_h"],means["mean"],"--",color=colors[treatment],label=treatment)
ax.set_yscale("log")
ax.set_xticks([1,2,4,8])
ax.set_xlabel("Time (h)")
ax.set_ylabel("CFU/mL, log10 scale")
ax.legend(fontsize=8)
fig.tight_layout()
for extension in ["png","svg","pdf"]:
    fig.savefig(out/f"lolamicin_points_means_python.{extension}",dpi=300,bbox_inches="tight")
plt.close(fig)

target_time=2
target=df.loc[(df["treatment"]=="Lolamicin (4X MIC)")&(df["time_h"]==target_time)]
values=target["value"].to_numpy()
mean=values.mean()
sd=values.std(ddof=1)
sem=sd/np.sqrt(len(values))
fig,axes=plt.subplots(1,2,figsize=(7,3.6),sharey=True)
for ax,error,title in zip(axes,[sd,sem],["Mean ± SD","Mean ± SEM"]):
    ax.scatter([-0.08,0,0.08],values,s=30,color="#0072B2",label="Observed values")
    ax.errorbar(0.3,mean,yerr=error,fmt="o",color="black",capsize=5,label=title)
    ax.set_xlim(-0.25,0.55)
    ax.set_xticks([])
    ax.set_title(title)
    ax.set_ylabel("CFU/mL, linear scale")
    ax.legend(fontsize=7)
fig.suptitle(f"Lolamicin, {target_time} h; n={len(values)}")
fig.tight_layout()
for extension in ["png","svg","pdf"]:
    fig.savefig(out/f"lolamicin_sd_sem_python.{extension}",dpi=300,bbox_inches="tight")
plt.close(fig)
print("rows",len(df),"groups",len(summary))
print("target",target_time,"h", "mean",mean,"sd",sd,"sem",sem)
(out/"lolamicin_plot_session.json").write_text(json.dumps({"python":platform.python_version(),"pandas":pd.__version__,"numpy":np.__version__,"matplotlib":matplotlib.__version__,"target_time":target_time,"SD_ddof":1},indent=2),encoding="utf-8")
