# 第7章练习包

本包从同一分析表绘图、导出并回查。NHANES演示分布与不同子图的有效记录数；Lolamicin演示全部原始点、均值和两种误差线。所有输入都已包含在本包内。

在解压后的本目录打开终端，Python环境安装requirements.txt中的三个包，R练习只需基础R。

```text
python scripts/01_nhanes_plot.py
python scripts/02_lolamicin_plot.py
Rscript scripts/03_lolamicin_plot.R
```

01对应7.1–7.3，写出未加权分布图、分母核对表及作图数据。02对应7.4–7.5，输出36条原始点图、12组汇总和2小时的SD/SEM比较图。03从同一36行CSV重新汇总，提供R对照。各入口可独立运行，均写入outputs。

打开PNG查看预览，再打开SVG或PDF检查轴、图例和裁切。填写design_card.md、records.md，完成exercises.md中的局部修改。下载包中的示例核对点用于演示检查，独立练习由你先预测再完成。
