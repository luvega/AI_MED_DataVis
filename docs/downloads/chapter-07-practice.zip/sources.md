# 来源与文件形成

NHANES2017–2018原始公开文件来自CDC，人口学DEMO_J与生化BIOPRO_J按SEQN一对一连接，筛选RIDSTATR=2、RIDAGEYR≥18、RIAGENDR为1或2。当前CSV沿用教材已有核验资产，来源SHA-256及下载地址在data/raw/nhanes_source_metadata.json。

- https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/DEMO_J.xpt
- https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/BIOPRO_J.xpt

Lolamicin数值来自Muñoz等作者源表41586_2024_7502_MOESM9_ESM.xlsx，ED Fig.3a的B2:J5。论文 https://www.nature.com/articles/s41586-024-07502-0 。本包CSV保留36个值及单元格对应，不提供跨时间样本身份推断。

脚本由本教材为当前教学任务编写，不包含外部付费课程讲义或受限资料。
