# 演示核对点

NHANES输入5533行；ALT有效5153（Male2480、Female2673），AST有效5137（Male2469、Female2668）。

Lolamicin输入36行，3处理×4时间形成12组，每组3条。Lolamicin 2小时均值25000、样本SD约23302.3604、SEM约13453.6240。Ciprofloxacin 4小时700/2400/200，均值1100。

SD用分母n−1，SEM按SD/√n计算。图中的纵坐标是原始CFU/mL，原始点和算术均值分别保存。
