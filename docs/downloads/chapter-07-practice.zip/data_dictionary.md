# 数据字典

NHANES成人分析表一行是一名符合纳入规则的参与者，共5533行。SEQN为参与者编号；sex为公开人口学分组；age_years为年龄（年）；ALT_U_L、AST_U_L为生化指标（U/L）。WTMEC2YR、SDMVPSU、SDMVSTRA为调查设计字段，本练习采用未加权描述。ALT、AST空白保留为缺失。来源元数据记录原始文件、连接键和纳入规则。

Lolamicin时间杀菌表36行，每行是指定处理、时间和源列中的CFU/mL值。

| 字段 | 含义 |
| --- | --- |
| treatment | 处理，原文标签 |
| time_h | 取样时间1、2、4、8小时 |
| repeat_column_index | 源三列中的次序1–3 |
| value | 换算后的CFU/mL |
| unit | CFU/mL |
| replicate_definition | 原图注中的生物学三重复说明 |
| source_sheet / source_cell | ED Fig. 3a及对应单元格 |

均值、SD、SEM在脚本中由同一value列计算；n是当前处理与时间下非缺失的数值条数。
