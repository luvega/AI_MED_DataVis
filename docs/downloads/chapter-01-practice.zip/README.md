# 第1章练习包

先读两张小表，手工数记录、参与者和缺失，再填写question_card.md。birth_mode_counts.csv对应1.1的434份问卷汇总，guesses.csv对应1.2–1.3的五行糖豆构造表。

本章以读表和确定问题为主。教师演示或课后想核对时，可在解压根目录运行 `python scripts/01_records.py`；脚本只使用Python标准库，将核对表写入outputs。独立任务在exercises.md，先独立作答再对照输出。

包内没有出生时刻逐人原始表，若任务需要按小时作图，应先说明缺少何种输入。
