# 数据字典

birth_mode_counts.csv保存正文已有434份出生调查的分娩方式填写汇总。mode为填写类别，count为该类别记录数；本包只含汇总，不含逐人出生时刻，不能从这三行恢复小时分布。

guesses.csv为五行独立构造教学表，record_id为回答记录号，participant_id为参与者，round为轮次，estimate_grains为估计粒数；空白是未填写。
