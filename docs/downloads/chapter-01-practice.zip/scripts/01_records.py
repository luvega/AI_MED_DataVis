"""只计算已有汇总及教学表的结构，不生成逐人出生数据。"""
from pathlib import Path
import csv
root=Path(__file__).resolve().parents[1]
out=root/"outputs"
out.mkdir(exist_ok=True)
with (root/"data/raw/birth_mode_counts.csv").open(encoding="utf-8-sig",newline="") as f:
    counts=list(csv.DictReader(f))
total=sum(int(row["count"]) for row in counts)
result=[{"mode":r["mode"],"count":int(r["count"]),"denominator":total,"percent":round(100*int(r["count"])/total,1)} for r in counts]
print("questionnaire_total",total)
print(result)
with (out/"birth_mode_percent.csv").open("w",encoding="utf-8",newline="") as f:
    w=csv.DictWriter(f,fieldnames=["mode","count","denominator","percent"])
    w.writeheader(); w.writerows(result)
with (root/"data/raw/guesses.csv").open(encoding="utf-8-sig",newline="") as f:
    guesses=list(csv.DictReader(f))
print("records",len(guesses),"participants",len({r["participant_id"] for r in guesses}),"missing_estimates",sum(r["estimate_grains"]=="" for r in guesses))
