"""核对计数、样本和配对结构；不拟合差异表达模型。"""
from pathlib import Path
import csv, json, hashlib
ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data/raw"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)
with (RAW / "airway_counts.csv").open(encoding="utf-8-sig", newline="") as f:
    reader=csv.DictReader(f); names=reader.fieldnames[1:]; rows=list(reader)
with (RAW / "airway_metadata.csv").open(encoding="utf-8-sig", newline="") as f:
    meta=list(csv.DictReader(f))
assert len({r["gene_id"] for r in rows})==len(rows)
assert len({r["sample_id"] for r in meta})==len(meta)
assert set(names)=={r["sample_id"] for r in meta}
by_id={r["sample_id"]:r for r in meta}
aligned=[by_id[s] for s in names]
assert all({r["dex"] for r in aligned if r["cell"]==c}=={"trt","untrt"} for c in {r["cell"] for r in aligned})
values=[[int(r[s]) for s in names] for r in rows]
assert all(x>=0 for row in values for x in row)
summary={"matrix_genes":len(rows),"matrix_samples":len(names),"cell_lines":len({r["cell"] for r in aligned}),"kept_total_count_ge_10":sum(sum(row)>=10 for row in values),"metadata_reordered":aligned!=meta,"design":"~ cell + dex","contrast":["dex","trt","untrt"],"sha256":{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in RAW.iterdir() if f.is_file()}}
(OUT/"input_audit.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(summary,ensure_ascii=False,indent=2))
