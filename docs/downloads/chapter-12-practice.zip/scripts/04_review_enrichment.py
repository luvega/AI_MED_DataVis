"""核对历史ORA表中的计数、超几何P值及方向内BH校正，不重新查询注释库。"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.stats import hypergeom

ROOT = Path(__file__).resolve().parents[1]
out = ROOT / "outputs"
out.mkdir(exist_ok=True)
table = pd.read_csv(ROOT / "reference/enrichment_results.csv")
required = {"direction", "term_id", "selected_gene_count", "background_gene_count",
            "term_background_count", "overlap_gene_count", "p_value", "p_adjust_bh"}
assert required <= set(table.columns)
assert not table.duplicated(["direction", "term_id"]).any()
assert table.p_value.between(0, 1).all() and table.p_adjust_bh.between(0, 1).all()
assert (table.overlap_gene_count <= table.term_background_count).all()
assert (table.overlap_gene_count <= table.selected_gene_count).all()
assert (table.term_background_count <= table.background_gene_count).all()
# P(X >= k): draw N candidate genes from a background of M; n have this annotation.
table["recomputed_p"] = hypergeom.sf(
    table.overlap_gene_count - 1, table.background_gene_count,
    table.term_background_count, table.selected_gene_count,
)
table["recomputed_bh"] = np.nan
for direction, group in table.groupby("direction", sort=True):
    p = group.p_value.to_numpy()
    order = np.argsort(p)
    scaled = p[order] * len(p) / np.arange(1, len(p) + 1)
    adjusted_sorted = np.minimum.accumulate(scaled[::-1])[::-1].clip(0, 1)
    adjusted = np.empty(len(p))
    adjusted[order] = adjusted_sorted
    table.loc[group.index, "recomputed_bh"] = adjusted
p_matches = np.allclose(table.recomputed_p, table.p_value, rtol=1e-8, atol=1e-12)
bh_matches = np.allclose(table.recomputed_bh, table.p_adjust_bh, rtol=1e-8, atol=1e-12)
assert p_matches and bh_matches
table.to_csv(out / "reviewed_enrichment.csv", index=False, encoding="utf-8-sig")
report = {
    "input_status": "historical_GO_BP_ORA_reference_2026-08-21",
    "rows": len(table),
    "directions": {name: {"terms": len(group),
                           "selected_genes": sorted(group.selected_gene_count.unique().tolist()),
                           "background_genes": sorted(group.background_gene_count.unique().tolist())}
                   for name, group in table.groupby("direction")},
    "hypergeometric_p_matches": bool(p_matches),
    "direction_wise_BH_matches": bool(bh_matches),
    "maximum_p_difference": float(abs(table.recomputed_p - table.p_value).max()),
    "maximum_bh_difference": float(abs(table.recomputed_bh - table.p_adjust_bh).max()),
    "annotation_database_queried": False,
    "GSEA_run": False,
}
(out / "enrichment_review.json").write_text(
    json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(report, ensure_ascii=False, indent=2))
