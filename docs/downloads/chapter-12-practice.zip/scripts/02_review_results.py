"""离线审阅既有DESeq2结果，不重新建模；改阈值再核对行数。"""
from pathlib import Path
import argparse, json
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument("--padj",type=float,default=0.05)
parser.add_argument("--lfc",type=float,default=1.0)
args=parser.parse_args()
assert 0<args.padj<=1 and args.lfc>=0
out=ROOT/"outputs";out.mkdir(exist_ok=True)
table=pd.read_csv(ROOT/"data/raw/airway_reference_results.tsv",sep="\t")
assert {"gene_id","baseMean","log2FoldChange","lfcSE","pvalue","padj"}<=set(table.columns)
assert table.gene_id.is_unique and table.padj.dropna().between(0,1).all()
table["selected"]=table.padj.notna() & table.padj.lt(args.padj) & table.log2FoldChange.abs().ge(args.lfc)
table.to_csv(out/"reviewed_full_results.csv",index=False,encoding="utf-8-sig")
selected=table.loc[table.selected]
summary={"input_status":"cached_DESeq2_results_2026-07-10","rows":len(table),"nonmissing_padj":int(table.padj.notna().sum()),"padj_threshold":args.padj,"absolute_lfc_threshold":args.lfc,"selected":len(selected),"higher_in_trt":int(selected.log2FoldChange.gt(0).sum()),"lower_in_trt":int(selected.log2FoldChange.lt(0).sum())}
(out/"result_review.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
valid=table.dropna(subset=["log2FoldChange","padj"])
import numpy as np
fig,ax=plt.subplots(figsize=(7,5))
ax.scatter(valid.log2FoldChange,-np.log10(valid.padj.clip(lower=np.finfo(float).tiny)),c=valid.selected.map({True:"#b43a42",False:"#777777"}),s=5,alpha=.5)
ax.axvline(args.lfc,color="black",ls="--",lw=.7);ax.axvline(-args.lfc,color="black",ls="--",lw=.7)
ax.axhline(-np.log10(args.padj),color="black",ls="--",lw=.7)
ax.set(xlabel="log2 fold change (trt / untrt)",ylabel="-log10 adjusted P",title="Cached airway DESeq2 result review")
fig.savefig(out/"review_volcano.png",dpi=180,bbox_inches="tight");plt.close(fig)
print(json.dumps(summary,ensure_ascii=False,indent=2))
