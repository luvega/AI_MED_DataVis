# 本地完整计数建模；需要已安装 DESeq2，不下载或安装软件。
args_all <- commandArgs(trailingOnly=FALSE)
script <- sub("^--file=", "", args_all[grepl("^--file=", args_all)][1])
root <- normalizePath(file.path(dirname(script), ".."), mustWork=TRUE)
out <- file.path(root,"outputs");dir.create(out,showWarnings=FALSE)
if (!requireNamespace("DESeq2",quietly=TRUE)) stop("Install DESeq2 in your prepared R environment; offline Python review remains available.")
if (!requireNamespace("pheatmap",quietly=TRUE)) stop("pheatmap is needed for the local heatmap; prepare it before the offline exercise.")
suppressPackageStartupMessages(library(DESeq2))
counts <- read.csv(file.path(root,"data/raw/airway_counts.csv"),row.names=1,check.names=FALSE)
meta <- read.csv(file.path(root,"data/raw/airway_metadata.csv"),row.names=1)
stopifnot(!anyDuplicated(rownames(meta)),setequal(colnames(counts),rownames(meta)))
meta <- meta[match(colnames(counts),rownames(meta)),,drop=FALSE]
stopifnot(identical(colnames(counts),rownames(meta)))
meta$cell <- factor(meta$cell)
meta$dex <- relevel(factor(meta$dex),ref="untrt")
mat <- as.matrix(counts)
stopifnot(all(mat>=0),all(mat==floor(mat)))
storage.mode(mat) <- "integer"
dds <- DESeqDataSetFromMatrix(mat,meta,design=~ cell + dex)
keep <- rowSums(counts(dds))>=10
dds <- dds[keep,]
dds <- DESeq(dds,quiet=TRUE)
res <- results(dds,contrast=c("dex","trt","untrt"),alpha=.05)
tab <- data.frame(gene_id=rownames(res),as.data.frame(res))
write.csv(tab,file.path(out,"native_deseq2_results.csv"),row.names=FALSE)
qc <- data.frame(sample_id=colnames(dds),size_factor=sizeFactors(dds),library_size=colSums(counts(dds)))
write.csv(qc,file.path(out,"native_sample_qc.csv"),row.names=FALSE)
write.csv(model.matrix(design(dds),as.data.frame(colData(dds))),
          file.path(out,"native_design_matrix.csv"),row.names=TRUE)
selected <- !is.na(tab$padj)&tab$padj<.05&abs(tab$log2FoldChange)>=1
write.csv(tab[selected,],file.path(out,"native_selected_results.csv"),row.names=FALSE)
# VST supplies the display matrix; the differential model above used raw counts.
vsd <- vst(dds,blind=FALSE)
pca <- plotPCA(vsd,intgroup=c("dex","cell"),returnData=TRUE,ntop=500)
variance <- 100*attr(pca,"percentVar")
write.csv(pca,file.path(out,"native_pca_coordinates.csv"),row.names=FALSE)
write.csv(data.frame(component=c("PC1","PC2"),percent_variance=variance),
          file.path(out,"native_pca_variance.csv"),row.names=FALSE)
png(file.path(out,"native_pca.png"),width=1200,height=900,res=150)
colors <- c(untrt="#2878B5",trt="#D55E00")
symbols <- seq_along(levels(pca$cell))+14
plot(pca$PC1,pca$PC2,col=colors[as.character(pca$dex)],
     pch=symbols[as.integer(pca$cell)],cex=1.5,
     xlab=sprintf("PC1 (%.2f%%)",variance[1]),
     ylab=sprintf("PC2 (%.2f%%)",variance[2]),main="airway: VST, 500 highest-variance genes")
legend("topright",legend=names(colors),col=colors,pch=16,bty="n")
legend("bottomleft",legend=levels(pca$cell),pch=symbols,bty="n")
dev.off()
# Select by adjusted P, then show each gene's relative sample pattern.
ordered <- tab[order(tab$padj,na.last=TRUE),]
top_ids <- head(ordered$gene_id[!is.na(ordered$padj)],30)
heat_mat <- assay(vsd)[top_ids,,drop=FALSE]
heat_mat <- t(scale(t(heat_mat)))
stopifnot(all(is.finite(heat_mat)))
write.csv(heat_mat,file.path(out,"native_heatmap_row_zscore.csv"),row.names=TRUE)
annotation <- data.frame(cell=colData(dds)$cell,dex=colData(dds)$dex,
                         row.names=colnames(dds))
pheatmap::pheatmap(heat_mat,annotation_col=annotation,cluster_rows=TRUE,cluster_cols=TRUE,
                   color=colorRampPalette(c("#2166AC","#FFFFFF","#B2182B"))(101),
                   filename=file.path(out,"native_heatmap.png"),width=9,height=9)
summary <- data.frame(item=c("input_genes","samples","retained_genes","nonmissing_padj","selected","up","down","DESeq2"),value=c(nrow(mat),ncol(mat),nrow(tab),sum(!is.na(tab$padj)),sum(selected),sum(selected&tab$log2FoldChange>0),sum(selected&tab$log2FoldChange<0),as.character(packageVersion("DESeq2"))))
write.csv(summary,file.path(out,"native_model_summary.csv"),row.names=FALSE)
capture.output(sessionInfo(),file=file.path(out,"native_session.txt"))
print(summary,row.names=FALSE)
