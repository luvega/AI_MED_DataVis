# 第12章学生练习：airway 的输入、建模与结果审阅

从本章正文的样本表进入，先核对计数列与元数据，再选择原生 R 建模或离线结果审阅。两条路线使用同一研究比较，输出状态分别记录。数据为公开 airway 软件包的完整计数与样本信息，含63,677个基因、8个样本、4个细胞系，每个细胞系有trt/untrt配对。`airway_reference_results.tsv` 是2026-07-10既有DESeq2运行结果，不是本次脚本新计算结果。

在解压后的 practice 目录运行：

```powershell
python scripts/01_audit_inputs.py
python scripts/02_review_results.py
```

第一项使用Python标准库；第二项需要pandas、numpy、matplotlib。先预测对齐后的样本数和计数总和≥10保留行数，再读 `outputs/input_audit.json`。第二项产生完整审阅表、火山图和参数记录。

已有R/DESeq2和pheatmap环境可运行：

```powershell
Rscript scripts/03_deseq2.R
```

R入口从本地计数重新拟合`~ cell + dex`模型；显式比较trt相对untrt。脚本不安装依赖、不访问网络。除完整结果、阈值子表和样本标准化因子外，脚本还保存设计矩阵、VST后PCA坐标与解释方差、前30个基因的行z-score热图及其输入表。PCA使用方差最大的500个基因，热图按padj选择基因。安装包、R版本与结果字段应写入运行记录。未备好R环境时，先完成离线读表任务，记录尚未重新建模。

先用默认阈值核对正文已给出的结果，再把`--lfc`改为2，预测变化后运行并记录。独立练习与提交要求见 `exercises/独立练习.md`，文件含义见 `data/data_dictionary.md`，来源见 `sources/来源.md`。

12.6使用的历史GO Biological Process ORA表位于`reference/enrichment_results.csv`。它保留2026-08-21课程材料中的4,242条参考结果（上调2,080条，下调2,162条），背景13,927个基因，映射后的上调391、下调376个候选基因。本地核对需要pandas、numpy和scipy：

```powershell
python scripts/04_review_enrichment.py
```

该脚本依据表中集合计数重算超几何P值，再在每个方向内核对BH校正，输出`enrichment_review.json`和逐条核对表。它不查询注释库、不重做ID映射；GSEA没有运行。结合来源与数据库版本审阅正文的富集解释。
