# 数据字典

| 文件或字段 | 含义与单位 | 处理状态 |
| --- | --- | --- |
| airway_counts.csv | 行为Ensembl基因ID、列为8个SRR样本；非负整数基因计数 | airway公开软件包原count assay；完整矩阵 |
| sample_id | 与矩阵列完全对应的run ID | 标签，不是数值变量 |
| cell | 4个细胞系；处理比较的配对区组 | 分组因子 |
| dex | trt地塞米松处理，untrt未处理 | 参照方向在脚本明确指定 |
| airway_reference_results.tsv | 22,369行既有DESeq2结果 | 2026-07-10缓存结果，非原始计数 |
| baseMean | 模型标准化计数平均值 | 数值 |
| log2FoldChange | trt/untrt表达比的log2估计 | 有方向效应量 |
| lfcSE/stat/pvalue/padj | 标准误、Wald统计量、P值与BH调整后P值 | 缺失padj保留为空 |
| direction/pass_teaching_threshold | 既有整理字段 | 本轮脚本重新按显式参数产生selected |

| reference/enrichment_results.csv | 历史GO BP ORA结果；每行是一个方向内的一个GO词条 | 4,242条，参考结果身份保留 |
| selected_gene_count / background_gene_count | 候选集合及背景集合的基因数 | 计数，无单位 |
| term_background_count / overlap_gene_count | 背景中该注释的基因数、候选集合中命中数 | 超几何检验的集合计数 |
| p_value / p_adjust_bh | ORA原始P值、每个方向内BH调整P值 | 与差异表达表中的padj不同 |
| gene_symbols / evidence_boundary | 命中基因符号、原表解释说明 | 原样保留 |
