# 第4章练习包

本包帮助你从三条CFU记录开始，亲手输入、预测、运行和保存短程序，再检查糖豆表中的对象、缺失、索引和函数。Python先学，R用于已熟悉问题的对照。

解压后在本目录打开终端。基础环境为Python和pandas；R脚本使用基础R。安装依赖使用 `python -m pip install -r requirements.txt`。

```text
python scripts/01_mean_cfu.py
python scripts/02_objects.py
python scripts/03_conditions_functions.py
Rscript scripts/04_objects.R
```

01对应4.1与4.5，先阅读后把关键五行自己输入解释器。02对应4.2–4.3，运行前手工圈出阈值950保留的记录。03对应4.4，指出函数输入和返回值。04用同一糖豆表和CFU表对照位置、名称和条件。

演示脚本可独立运行，不要求复用前一次会话里的对象。所有结果写入outputs。完成exercises.md中的条件变化题，在records.md填写本人记录。reference仅含演示核对信息，独立任务由你完成。
