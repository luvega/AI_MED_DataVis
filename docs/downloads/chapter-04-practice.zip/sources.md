# 数据来源

糖豆表是本教材独立构造的五行教学数据，演示重复回答、缺失、对象与定位。

Lolamicin记录来自Muñoz等论文作者提供的源表 `41586_2024_7502_MOESM9_ESM.xlsx`，工作表ED Fig. 3a。论文 https://www.nature.com/articles/s41586-024-07502-0 。本包只提供已核对的六条数值和来源字段；原图注说明为生物学三重复，repeat_column_index记录源列次序，跨时间配对信息仍须根据原研究定义。
