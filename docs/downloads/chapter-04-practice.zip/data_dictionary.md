# 数据字典

`guesses.csv`为五行教学构造表，一行代表一次糖豆估计回答。

| 字段 | 类型与含义 |
| --- | --- |
| record_id | 文本；一次回答的记录号 |
| participant_id | 文本；参与者编号，同一参与者可以多轮出现 |
| round | 整数；回答轮次1或2 |
| estimate_grains | 数值；估计的糖豆粒数，空白保留为缺失 |

`lolamicin_2_8h.csv`为作者源表中Lolamicin处理2、8小时的六条记录。

| 字段 | 类型与含义 |
| --- | --- |
| treatment | 文本；Lolamicin (4X MIC) |
| time_h | 数值；取样时间，小时 |
| repeat_column_index | 整数；当前三列中的顺序1–3 |
| value | 数值；CFU/mL |
| unit | 文本；CFU/mL |
| replicate_definition | 文本；原图注的重复说明 |
| source_sheet | 文本；ED Fig. 3a |
| source_cell | 文本；源工作表单元格 |

输入CSV为UTF-8，可接受BOM。字段含义、单位和来源与正文一致。
