"""4.2/4.3：用一张五行表核对缺失、位置、名称与条件。"""
from pathlib import Path
import pandas as pd

root = Path(__file__).resolve().parents[1]
frame = pd.read_csv(root / "data/raw/guesses.csv", dtype={"record_id": "string", "participant_id": "string"})
print(frame)
print("shape", frame.shape)
print("participants", frame["participant_id"].nunique())
print("missing", frame["estimate_grains"].isna().sum())
print("first_record", frame.iloc[0, 0])
print(frame.loc[frame["record_id"] == "r04", ["participant_id", "estimate_grains"]])

threshold = 950
keep = frame["estimate_grains"].notna() & (frame["estimate_grains"] >= threshold)
selected = frame.loc[keep, ["record_id", "estimate_grains"]]
print("selected", selected.to_dict("records"))
(root / "outputs").mkdir(exist_ok=True)
selected.to_csv(root / "outputs/selected_python.csv", index=False, encoding="utf-8")
