"""4.1/4.5：Lolamicin 4×MIC、2小时，ED Fig.3a E3/F3/G3，CFU/mL。"""
from pathlib import Path
import csv

values = [6000, 18000, 51000]
time_h = 2
total = sum(values)
n = len(values)
mean_cfu = total / n
print("values", values)
print("total", total, "n", n, "mean_cfu", mean_cfu)

output = Path(__file__).resolve().parents[1] / "outputs"
output.mkdir(exist_ok=True)
with (output / "mean_cfu_python.csv").open("w", encoding="utf-8", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["time_h", "n", "total", "mean_cfu", "unit"])
    writer.writerow([time_h, n, total, mean_cfu, "CFU/mL"])
