"""4.4：检查函数返回缺少的列名，保持输入表。"""
from pathlib import Path
import json
import pandas as pd

def missing_columns(table, required_names):
    missing = []
    for name in required_names:
        if name not in table.columns:
            missing.append(name)
    return missing

root = Path(__file__).resolve().parents[1]
frame = pd.read_csv(root / "data/raw/guesses.csv")
required = ["record_id", "participant_id", "round", "estimate_grains"]
for name in required:
    print(name, name in frame.columns)
missing = missing_columns(frame, required + ["unit"])
print("missing_columns", missing)
print("input_shape_after_call", frame.shape)
(root / "outputs").mkdir(exist_ok=True)
(root / "outputs/column_check.json").write_text(json.dumps({"missing": missing, "shape": list(frame.shape)}, indent=2), encoding="utf-8")
