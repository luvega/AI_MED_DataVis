# 同一糖豆表及Lolamicin表的基础R对照。
args <- commandArgs(trailingOnly=FALSE)
script <- sub("^--file=", "", args[grepl("^--file=", args)])
root <- normalizePath(file.path(dirname(script), ".."), winslash="/")
out <- file.path(root, "outputs")
dir.create(out, showWarnings=FALSE)
frame <- read.csv(file.path(root, "data/raw/guesses.csv"), stringsAsFactors=FALSE)
print(dim(frame))
print(frame[1, 1])
keep <- !is.na(frame$estimate_grains) & frame$estimate_grains >= 950
selected <- frame[keep, c("record_id", "estimate_grains"), drop=FALSE]
print(selected)
write.csv(selected, file.path(out, "selected_r.csv"), row.names=FALSE)
cfu <- read.csv(file.path(root, "data/raw/lolamicin_2_8h.csv"), stringsAsFactors=FALSE)
target <- cfu[cfu$time_h == 2, , drop=FALSE]
print(target[, c("time_h", "value", "source_cell")])
print(mean(target$value))
write.csv(target, file.path(out, "cfu_selected_r.csv"), row.names=FALSE)
