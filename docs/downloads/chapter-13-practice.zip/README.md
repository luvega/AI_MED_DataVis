# 第13章学生练习：公共记录、序列格式与ID映射

本包让你在没有网络或凭据时，核对一条历史公共数据库记录、两组构造双端reads、一个构造VCF以及已保存的ID查询结果。FASTA、FASTQ和VCF为教学构造，来自不同对象层次，不能把它们当成真实测序流程产生的一套样本。ID映射是2026-07-10查询缓存；GSE35570记录是同日已保存观察，不代表今天重新查询。

在解压的practice目录运行：

```powershell
python scripts/01_check_sequences.py
python scripts/02_map_ids.py
```

两个入口只使用Python标准库，按脚本位置寻找文件。运行前手数FASTA记录、read记录与VCF类型，运行后逐项核对 `outputs/format_audit.json`。第二个入口保留成功与未匹配ID，检查查询日期与物种字段。

参考结果可从正文的构造VCF表和ID表核对；独立练习见 `exercises/独立练习.md`。需要拓展时从 `sources/来源.md` 的官方链接自行核验公共记录与许可，再决定是否下载。基础任务没有在线查询和完整测序下载。
