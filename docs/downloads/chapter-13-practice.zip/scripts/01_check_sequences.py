"""本地构造小文件的结构检查；无下载、比对或医学判读。"""
from pathlib import Path
import csv,json,hashlib
from collections import Counter
ROOT=Path(__file__).resolve().parents[1];raw=ROOT/"data/raw";out=ROOT/"outputs";out.mkdir(exist_ok=True)
def read_fastq(path):
    lines=path.read_text(encoding="utf-8").splitlines()
    assert len(lines)%4==0,"FASTQ line number must be divisible by four"
    result=[]
    for i in range(0,len(lines),4):
        name,seq,plus,qual=lines[i:i+4]
        assert name.startswith("@") and plus.startswith("+")
        assert len(seq)==len(qual) and set(seq)<=set("ACGTN")
        result.append((name.split()[0].rsplit("/",1)[0],seq))
    return result
r1=read_fastq(raw/"teaching_reads_R1.fastq");r2=read_fastq(raw/"teaching_reads_R2.fastq")
assert len(r1)==len(r2) and [x[0] for x in r1]==[x[0] for x in r2]
fasta_ids=[x[1:].split()[0] for x in (raw/"teaching_reference.fasta").read_text().splitlines() if x.startswith(">")]
assert len(fasta_ids)==len(set(fasta_ids))
types=Counter();filters=Counter();rows=[]
for line in (raw/"teaching_variants.vcf").read_text(encoding="utf-8-sig").splitlines():
    if line.startswith("#"):continue
    chrom,pos,vid,ref,alt,qual,filt,info=line.split("\t")[:8]
    kind="SNP" if len(ref)==len(alt)==1 else "INS" if len(ref)<len(alt) else "DEL" if len(ref)>len(alt) else "OTHER"
    assert int(pos)>0 and "," not in alt,"This teaching parser only handles single ALT records"
    types[kind]+=1;filters[filt]+=1;rows.append(dict(chrom=chrom,pos=pos,id=vid,ref=ref,alt=alt,filter=filt,kind=kind))
with (out/"parsed_variants.csv").open("w",encoding="utf-8-sig",newline="") as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={"status":"constructed_non_patient_inputs","fasta_records":len(fasta_ids),"R1_records":len(r1),"R2_records":len(r2),"mate_ids_aligned":True,"variant_types":dict(types),"filters":dict(filters),"sha256":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in raw.iterdir() if p.is_file()}}
(out/"format_audit.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8");print(json.dumps(summary,ensure_ascii=False,indent=2))
