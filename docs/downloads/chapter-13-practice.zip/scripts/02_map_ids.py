"""审阅2026-07-10保存的Ensembl映射，不连接在线数据库。"""
from pathlib import Path
import csv,json
ROOT=Path(__file__).resolve().parents[1];out=ROOT/"outputs";out.mkdir(exist_ok=True)
with (ROOT/"data/raw/ensembl_id_mapping.csv").open(encoding="utf-8-sig",newline="") as f: rows=list(csv.DictReader(f))
assert rows and len(rows)==4
print("Cached column names:",list(rows[0]))
status_key="mapping_status"
assert status_key in rows[0]
summary={"query_date":"2026-07-10","mode":"offline_saved_lookup","records":len(rows),"status_counts":{s:sum(r[status_key]==s for r in rows) for s in sorted({r[status_key] for r in rows})}}
with (out/"reviewed_id_mapping.csv").open("w",encoding="utf-8-sig",newline="") as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(out/"id_mapping_audit.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8");print(json.dumps(summary,ensure_ascii=False,indent=2))
