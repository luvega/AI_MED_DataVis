# 数据字典

| 文件或字段 | 单位与含义 | 来源状态 |
| --- | --- | --- |
| teaching_reference.fasta | 2条构造核酸序列；标题后为序列 | 教学构造，非真实参考基因组 |
| teaching_reads_R1/R2.fastq | 每端2条构造read；每read四行，序列与质量长度相同 | 非患者数据，与上述FASTA未经过比对 |
| teaching_variants.vcf | 4条构造候选：CHROM/POS/ID/REF/ALT/QUAL/FILTER/INFO | POS为一基坐标；不做变异致病性判定 |
| FILTER | PASS或LowQual | 流程过滤字段 |
| ensembl_id_mapping.csv | 原始ID、查询ID、显示名称、物种、组装、状态等 | 2026-07-10已保存Ensembl查询；模拟无效ID保留 |
| public_record_snapshot.csv | GSE35570数据库116条sample记录与65例病例 | 2026-07-10历史记录，两种口径不可互换 |
