# 第6章整形与汇总练习

从本包根目录运行

```powershell
python scripts/01_reshape_summary.py
python scripts/02_inventory_summary.py
Rscript scripts/03_summary.R
```

01以36条实验测量形成12行宽表，回到36行长表，再按三个键恢复源单元格并生成12组汇总。02使用与第5章相同的23条库存分析记录，统计与作图共享输入。03用基础R核对同一实验分组的n、均值、中位数、SD和SEM。每次运行结果写入outputs。依赖见requirements.txt。图中英文Form编号可回到inventory_by_form.csv对照真实构造标签。

04迁移练习读取本章4×4指标宽表与4×2分组表，恢复4×5表后转为12×4长表；读取8行销售摘录和7行分类表，完成多对一连接、日期解析和汇总。运行 `python scripts/04_transfer.py`。这些输入与正文内嵌示例逐值对应。
