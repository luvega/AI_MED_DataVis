# 数据字典

| 文件/字段 | 含义 | 核对方法 |
|---|---|---|
| treatment | 源图处理条件，文本 | 保留4X MIC条件及原标签 |
| time_h | 测量时间，小时 | 1、2、4、8 |
| repeat_column_index | 源表三条重复列的序号 | 与source_cell一起核对 |
| value | 活菌计数，CFU/mL | 保存原值，分组汇总保留全部三条记录 |
| source_sheet / source_cell | 作者源表定位 | 回查ED Fig. 3a |
| Drug_ID | 构造库存记录编号 | 文本，区分记录与商品 |
| Stock_Qty | 构造库存数量 | 空白与负值分别标记，0为有效数值 |
| Unit_Price_CNY | 构造单价字段 | 本任务汇总库存时不因单价缺失排除 |
| Expiry_Date / Last_Received | 构造日期 | 保留原文，解析后列出失败项 |
| Dosage_Form / Drug_Name / Supplier | 构造标签 | 重复候选需结合业务记录定义；本练习只标记 |

迁移表：clinical_wide_teaching为4个教学样本×3个数值指标；clinical_groups_teaching按sample_id提供A/B教学分组。ALT、AST、creatinine沿用原示例数值，未设医学单位和参考范围，仅在各字段内整形与汇总。sales_excerpt_teaching的card_id、drug_code按文本保留；quantity为示例销售数量，金额字段为素材原数值，单位沿用未定义状态，不能解释为当前业务货币金额。drug_reference_teaching每个drug_code一行，提供分类映射。
