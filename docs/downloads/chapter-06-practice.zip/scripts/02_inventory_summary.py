from pathlib import Path
import pandas as pd
BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'outputs'
OUT.mkdir(exist_ok=True)

raw=pd.read_csv(BASE/'data/raw/inventory_teaching.csv',encoding='utf-8-sig',dtype=str,keep_default_na=False)
stock=pd.to_numeric(raw['Stock_Qty'],errors='coerce')
analysis=raw.loc[stock.notna() & stock.ge(0)].copy()
analysis['stock_num']=stock.loc[analysis.index]
analysis['expiry_parsed']=pd.to_datetime(analysis['Expiry_Date'],format='mixed',errors='coerce')
analysis['dosage_form_clean']=analysis['Dosage_Form'].str.strip()
summary=analysis.groupby('dosage_form_clean',as_index=False).agg(records=('Drug_ID','size'),stock_total=('stock_num','sum'),mean_stock=('stock_num','mean'),median_stock=('stock_num','median'))
assert summary['records'].sum()==len(analysis)
assert summary['stock_total'].sum()==analysis['stock_num'].sum()
analysis.to_csv(OUT/'inventory_analysis.csv',index=False)
summary.to_csv(OUT/'inventory_by_form.csv',index=False)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(6,3.6),layout='constrained')
ax.bar(range(len(summary)),summary['stock_total'],color='#237d86')
ax.set(xticks=range(len(summary)),xticklabels=[f'Form {i+1}' for i in range(len(summary))],ylabel='Constructed stock quantity',title='Teaching inventory: same analysis table')
fig.savefig(OUT/'inventory_by_form.png',dpi=160)
plt.close(fig)
print(summary.to_string(index=False))
print('图中Form编号按结果表行顺序对应剂型；库存数量未提供统一包装单位，不跨药品解释为可比剂量。')
