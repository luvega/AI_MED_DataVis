from pathlib import Path
import pandas as pd

BASE=Path(__file__).resolve().parents[1]
RAW=BASE/'data/raw'
OUT=BASE/'outputs'
OUT.mkdir(exist_ok=True)
wide=pd.read_csv(RAW/'clinical_wide_teaching.csv',dtype={'sample_id':str})
groups=pd.read_csv(RAW/'clinical_groups_teaching.csv',dtype={'sample_id':str})
joined=wide.merge(groups,on='sample_id',how='left',validate='one_to_one',indicator=True)
assert joined['_merge'].eq('both').all()
joined=joined.drop(columns='_merge')
long=joined.melt(id_vars=['sample_id','group'],value_vars=['ALT','AST','creatinine'],var_name='marker',value_name='value')
summary=long.groupby(['group','marker'],as_index=False).agg(n=('value','count'),mean=('value','mean'),median=('value','median'),sd=('value','std'))
sales=pd.read_csv(RAW/'sales_excerpt_teaching.csv',dtype={'card_id':str,'drug_code':str})
reference=pd.read_csv(RAW/'drug_reference_teaching.csv',dtype={'drug_code':str})
sale_joined=sales.merge(reference,on='drug_code',how='left',validate='many_to_one',indicator=True)
sale_joined['sale_date']=pd.to_datetime(sale_joined['sale_date'],errors='raise')
daily=sale_joined.groupby('sale_date',as_index=False).agg(transactions=('drug_code','size'),quantity=('quantity','sum'),actual=('actual','sum'))
assert len(wide)==4 and len(long)==12 and len(sale_joined)==8
print('分类连接状态',sale_joined['_merge'].value_counts().to_dict())
print('未匹配编码',sale_joined.loc[sale_joined['_merge'].eq('left_only'),'drug_code'].unique().tolist())
for name,table in [('clinical_long',long),('clinical_summary',summary),('sales_joined',sale_joined),('sales_daily',daily)]:
    table.to_csv(OUT/f'{name}.csv',index=False)
print('指标宽表',joined.shape,'长表',long.shape,'销售连接表',sale_joined.shape)
print(daily.to_string(index=False))
