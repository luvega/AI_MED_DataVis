from pathlib import Path
import pandas as pd
BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'outputs'
OUT.mkdir(exist_ok=True)

import numpy as np
raw = pd.read_csv(BASE/'data/raw/lolamicin_ecoli_timekill.csv')
keys=['treatment','time_h','repeat_column_index']
required=set(keys+['value','unit','replicate_definition','source_sheet','source_cell'])
assert required.issubset(raw.columns)
assert not raw.duplicated(keys).any()
wide = raw.pivot(index=['treatment','time_h'],columns='repeat_column_index',values='value').reset_index()
repeat_columns=sorted(raw['repeat_column_index'].unique())
long = wide.melt(id_vars=['treatment','time_h'],value_vars=repeat_columns,var_name='repeat_column_index',value_name='value')
assert len(wide)==len(raw[['treatment','time_h']].drop_duplicates())
assert len(long)==len(raw), '检查是否选中了每组的完整记录；宽表可能补出空单元格'
locations = raw[keys+['unit','replicate_definition','source_sheet','source_cell']]
joined = long.merge(locations,on=keys,how='left',validate='one_to_one',indicator=True)
assert joined['_merge'].eq('both').all() and len(joined)==len(raw)
joined=joined.drop(columns='_merge')
summary = joined.groupby(['treatment','time_h'],as_index=False).agg(n=('value','count'),mean=('value','mean'),median=('value','median'),sd=('value','std'),minimum=('value','min'),maximum=('value','max'))
summary['sem']=summary['sd']/np.sqrt(summary['n'])
summary.to_csv(OUT/'group_summary.csv',index=False)
joined.to_csv(OUT/'joined_records.csv',index=False)
wide.to_csv(OUT/'wide_table.csv',index=False)
again=pd.read_csv(OUT/'joined_records.csv')
assert len(again)==len(raw) and again['value'].sum()==raw['value'].sum()
print('长表',raw.shape,'宽表',wide.shape,'连接后',joined.shape)
print(summary.to_string(index=False))
