from pathlib import Path
import pandas as pd
BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'outputs'
OUT.mkdir(exist_ok=True)

import numpy as np
raw = pd.read_csv(BASE/'data/raw/lolamicin_ecoli_timekill.csv')
assert raw.shape==(36,8)
keys=['treatment','time_h','repeat_column_index']
assert not raw.duplicated(keys).any()
wide = raw.pivot(index=['treatment','time_h'],columns='repeat_column_index',values='value').reset_index()
long = wide.melt(id_vars=['treatment','time_h'],value_vars=[1,2,3],var_name='repeat_column_index',value_name='value')
assert len(wide)==12 and len(long)==36
locations = raw[keys+['unit','replicate_definition','source_sheet','source_cell']]
joined = long.merge(locations,on=keys,how='left',validate='one_to_one',indicator=True)
assert joined['_merge'].eq('both').all() and len(joined)==36
joined=joined.drop(columns='_merge')
summary = joined.groupby(['treatment','time_h'],as_index=False).agg(n=('value','count'),mean=('value','mean'),median=('value','median'),sd=('value','std'),minimum=('value','min'),maximum=('value','max'))
summary['sem']=summary['sd']/np.sqrt(summary['n'])
row=summary.query('treatment == "Lolamicin (4X MIC)" and time_h == 2').iloc[0]
assert row['n']==3 and row['mean']==25000
summary.to_csv(OUT/'group_summary.csv',index=False)
joined.to_csv(OUT/'joined_records.csv',index=False)
wide.to_csv(OUT/'wide_table.csv',index=False)
again=pd.read_csv(OUT/'joined_records.csv')
assert len(again)==36 and again['value'].sum()==raw['value'].sum()
print('长表',raw.shape,'宽表',wide.shape,'连接后',joined.shape)
print(summary.to_string(index=False))
