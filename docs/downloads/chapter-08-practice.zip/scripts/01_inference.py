"""第8章完整演示；先保留输入，再写出可核对结果。"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'data/raw'; OUT=ROOT/'outputs'; OUT.mkdir(exist_ok=True)
data=pd.read_csv(RAW/'alt_ast.csv',encoding='utf-8-sig',dtype={'sample_id':str})
assert data.shape==(24,7) and data.sample_id.is_unique
assert data[['ALT','AST','group']].notna().all().all()
summary=[]; comparisons=[]
for indicator in ['ALT','AST']:
    for group,part in data.groupby('group',observed=True):
        x=part[indicator].to_numpy(dtype=float);n=len(x)
        mean=x.mean();sd=x.std(ddof=1);se=sd/np.sqrt(n)
        low,high=stats.t.interval(0.95,n-1,loc=mean,scale=se)
        summary.append(dict(indicator=indicator,group=group,n=n,mean=mean,SD=sd,SE=se,ci_low=low,ci_high=high))
    control=data.loc[data.group=='control',indicator].to_numpy(dtype=float)
    treatment=data.loc[data.group=='treatment',indicator].to_numpy(dtype=float)
    diff=treatment.mean()-control.mean()
    v1=control.var(ddof=1)/len(control);v2=treatment.var(ddof=1)/len(treatment)
    se=np.sqrt(v1+v2)
    df=(v1+v2)**2/(v1**2/(len(control)-1)+v2**2/(len(treatment)-1))
    low,high=stats.t.interval(0.95,df,loc=diff,scale=se)
    tt=stats.ttest_ind(treatment,control,equal_var=False)
    pooled=np.sqrt(((len(control)-1)*control.var(ddof=1)+(len(treatment)-1)*treatment.var(ddof=1))/(len(control)+len(treatment)-2))
    comparisons.append(dict(indicator=indicator,mean_diff=diff,SE=se,df=df,ci_low=low,ci_high=high,t_value=tt.statistic,p_value=tt.pvalue,cohen_d=diff/pooled))
pd.DataFrame(summary).to_csv(OUT/'group_summary.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(comparisons).to_csv(OUT/'welch_results.csv',index=False,encoding='utf-8-sig')

tea=pd.read_csv(RAW/'tea.csv',encoding='utf-8-sig')
counts=tea.correct_milk.value_counts().sort_index().rename_axis('correct_milk').reset_index(name='allocations')
counts['probability']=counts.allocations/len(tea)
assert counts.allocations.tolist()==[1,16,36,16,1]
counts.to_csv(OUT/'tea_distribution.csv',index=False)

sleep=pd.read_csv(RAW/'sleep.csv',dtype={'ID':str,'group':str},encoding='utf-8-sig')
paired=sleep.pivot(index='ID',columns='group',values='extra').dropna(subset=['1','2'])
paired['difference']=paired['2']-paired['1']
tt=stats.ttest_rel(paired['2'],paired['1']);n=len(paired)
se=paired.difference.std(ddof=1)/np.sqrt(n)
low,high=stats.t.interval(0.95,n-1,loc=paired.difference.mean(),scale=se)
paired.to_csv(OUT/'sleep_pairs.csv',encoding='utf-8-sig')
pd.DataFrame([dict(n_pairs=n,mean_diff=paired.difference.mean(),SE=se,ci_low=low,ci_high=high,t_value=tt.statistic,p_value=tt.pvalue)]).to_csv(OUT/'paired_results.csv',index=False)

ab=pd.read_csv(RAW/'ab.csv',encoding='utf-8-sig').set_index('group')
p_a=ab.loc['A','success']/ab.loc['A','n'];p_b=ab.loc['B','success']/ab.loc['B','n']
se=np.sqrt(p_a*(1-p_a)/ab.loc['A','n']+p_b*(1-p_b)/ab.loc['B','n'])
pooled=ab.success.sum()/ab.n.sum()
null_se=np.sqrt(pooled*(1-pooled)*(1/ab.loc['A','n']+1/ab.loc['B','n']))
z=(p_b-p_a)/null_se;p_value=2*stats.norm.sf(abs(z))
pd.DataFrame([dict(p_A=p_a,p_B=p_b,difference=p_b-p_a,ci_low=p_b-p_a-1.96*se,ci_high=p_b-p_a+1.96*se,z=z,p_value=p_value)]).to_csv(OUT/'ab_results.csv',index=False)
multiple=pd.read_csv(RAW/'multiple_tests.csv',encoding='utf-8-sig')
multiple['reject'],multiple['padj'],_,_=multipletests(multiple.p_value,method='fdr_bh')
multiple.to_csv(OUT/'multiple_tests_bh.csv',index=False,encoding='utf-8-sig')
print(pd.DataFrame(summary).round(6).to_string(index=False))
print(pd.DataFrame(comparisons).round(6).to_string(index=False))
print(f'tea allocations={len(tea)} P(all correct)={1/len(tea):.6f}')
print(f'sleep pairs={n} mean difference={paired.difference.mean():.3f} P={tt.pvalue:.6f}')
print(f'A/B difference={p_b-p_a:.3f} P={p_value:.6f}')
print(multiple.to_string(index=False))
