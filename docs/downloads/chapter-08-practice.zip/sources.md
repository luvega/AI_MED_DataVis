# 来源

ALT/AST来自本章原有明确标识的固定教学构造数据。tea是教材独立枚举的70种分配，杯号1—4设为先加奶；不代表历史实验观察。sleep来自R datasets::sleep（R 4.6.0），保留COPYING-R.txt，GPL-2或GPL-3。A/B是教材原创构造汇总，两组各5000名不同用户，success为1350/1450。multiple_tests为本章固定教学输入。

方法与数据说明

- https://stat.ethz.ch/R-manual/R-devel/library/datasets/html/sleep.html
- 八杯茶原始方法说明 https://mystatclass.com/media/Fisher_paper.pdf
- A/B观察单位核对 https://www.microsoft.com/en-us/research/publication/diagnosing-sample-ratio-mismatch-in-online-controlled-experiments-a-taxonomy-and-rules-of-thumb-for-practitioners/

使用这些数据展开抽样、检验及报告练习。医学解释及协作职责统一见正文8.5。
