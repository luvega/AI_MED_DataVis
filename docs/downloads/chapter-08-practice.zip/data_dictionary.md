# 数据字典

| 文件 | 字段与单位 | 观察单位 |
| --- | --- | --- |
| alt_ast.csv | sample_id编号；group教学分组；ALT/AST教学值U/L；age岁；sex教学标签；response教学标签 | 每行一个构造样本，共24行 |
| tea.csv | selected选中的4个杯号；correct_milk其中实际先加奶杯数 | 每行一种随机分配，70种，非70名受试者 |
| sleep.csv | ID历史受试者编号；group条件1/2；extra相对对照增加小时数 | 20行，10人，每人两条件 |
| ab.csv | group页面版本；n不同用户数；success完成预约用户数 | 两行汇总，各5000人，教学构造 |
| multiple_tests.csv | indicator指标名；p_value预设演示P值 | 六项共同问题族；前两项为四舍五入示例值，其余为构造输入 |
