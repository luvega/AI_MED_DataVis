# 第2章练习包

本包检查Python入口、工作目录、实际依赖和释放表路径，帮助你把一次运行与文件位置对应起来。基础入口只使用标准库，R入口只用基础R。

在解压根目录依次运行。

```text
python scripts/01_environment.py
python scripts/02_release_path.py
Rscript scripts/03_environment.R
```

01报告当前Python和三个后续练习包状态，未安装的包如实标记。02读本包12行构造释放表并写出报告。03记录R版本与最小计算，不要求安装领域包。每个脚本可独立运行，结果写outputs。

想查看某条语句，可以先输入 `2 + 3`，随后用print保存为短脚本。系统终端与Python交互提示符的区别参见正文。填写records.md与exercises.md。
