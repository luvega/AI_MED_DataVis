# 只核对基础R运行和实际入口，不安装包。
args <- commandArgs(trailingOnly=FALSE)
script <- sub("^--file=", "", args[grepl("^--file=", args)])
root <- normalizePath(file.path(dirname(script),".."),winslash="/")
out <- file.path(root,"outputs")
dir.create(out,showWarnings=FALSE)
result <- c(paste("R_version",R.version.string),paste("R_home",R.home()),paste("working_directory",getwd()),paste("project_root",root),paste("basic_calculation",2+3))
writeLines(result,file.path(out,"environment_r.txt"))
cat(paste(result,collapse="\n"),"\n")
