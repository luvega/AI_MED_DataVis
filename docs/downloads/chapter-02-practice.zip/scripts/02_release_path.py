"""在相同项目中核对工作目录与按脚本位置建立的输入路径。"""
from pathlib import Path
import csv
import json
root=Path(__file__).resolve().parents[1]
path=root/"data/raw/release_teaching.csv"
print("working_directory",Path.cwd())
print("input_path",path)
with path.open(encoding="utf-8-sig",newline="") as f:
    reader=csv.DictReader(f)
    fields=reader.fieldnames
    rows=list(reader)
result={"working_directory":str(Path.cwd()),"input_path":str(path),"fields":fields,"records":len(rows),"units":len({r["unit_id"] for r in rows}),"times":sorted({int(r["time_min"]) for r in rows})}
print("records",result["records"],"units",result["units"],"times",result["times"])
(root/"outputs").mkdir(exist_ok=True)
(root/"outputs/release_path_report.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
