"""读取环境状态，不安装依赖。"""
from pathlib import Path
import importlib
import json
import sys
root=Path(__file__).resolve().parents[1]
packages={}
for name in ["pandas","matplotlib","openpyxl"]:
    try:
        module=importlib.import_module(name)
        packages[name]={"status":"available","version":getattr(module,"__version__","unknown")}
    except ImportError:
        packages[name]={"status":"not_installed"}
result={"python_executable":sys.executable,"python_version":sys.version,"working_directory":str(Path.cwd()),"project_root":str(root),"packages":packages,"basic_calculation":2+3}
(root/"outputs").mkdir(exist_ok=True)
(root/"outputs/environment_python.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(result,ensure_ascii=False,indent=2))
